<?php
/**
 * Uninstall script — runs when plugin is deleted.
 *
 * Only cleans up plugin-owned data; WooCommerce orders are untouched.
 *
 * @package SukunaatOrderManager
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/*
 * The plugin stores notes as WooCommerce order meta (_sukunaat_admin_note).
 * We do NOT delete those by default so that order history is preserved.
 * If you wish to clean up, uncomment the block below.
 */

/*
global $wpdb;
$wpdb->delete(
	$wpdb->postmeta,
	[ 'meta_key' => '_sukunaat_admin_note' ],
	[ '%s' ]
);
*/
