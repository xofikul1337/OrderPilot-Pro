<?php
defined( 'ABSPATH' ) || exit;

$notif   = \SukunaatOrderManager\Notifications::instance();
$code    = $notif->get_store_code();
$enabled = $notif->is_enabled();
$last_err = get_option( 'som_last_notification_error', '' );
$last_ok  = get_option( 'som_last_notification_sent_at', '' );
$last_res = get_option( 'som_last_notification_response', '' );
?>
<div class="wrap som-wrap">

	<div class="som-staff-header">
		<div>
			<h1>🔔 <?php esc_html_e( 'Push Notifications', 'sukunaat-order-manager' ); ?></h1>
			<p><?php esc_html_e( 'Connect OrderPilot Pro app to receive instant order alerts on all staff phones.', 'sukunaat-order-manager' ); ?></p>
		</div>
		<a class="som-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=sukunaat-order-manager' ) ); ?>">
			← <?php esc_html_e( 'Back to Orders', 'sukunaat-order-manager' ); ?>
		</a>
	</div>

	<!-- ── Store Code Card ──────────────────────────────────── -->
	<div class="snc-card">
		<div class="snc-card-title">🔑 <?php esc_html_e( 'Store Code', 'sukunaat-order-manager' ); ?></div>

		<div class="snc-card-body">

			<?php if ( $code ) : ?>
			<!-- Code is set — show it -->
			<div class="snc-code-display">
				<div class="snc-code-big" id="snc-code-display"><?php echo esc_html( $code ); ?></div>
				<div class="snc-code-actions">
					<button type="button" class="snc-btn-copy" onclick="sncCopy('<?php echo esc_js( $code ); ?>')">
						📋 <?php esc_html_e( 'Copy', 'sukunaat-order-manager' ); ?>
					</button>
					<button type="button" class="snc-btn-change" onclick="sncShowInput()">
						✏️ <?php esc_html_e( 'Change', 'sukunaat-order-manager' ); ?>
					</button>
				</div>
			</div>
			<div id="snc-copied-msg" class="snc-copied-msg" style="display:none">✅ <?php esc_html_e( 'Copied!', 'sukunaat-order-manager' ); ?></div>
			<?php endif; ?>

			<!-- Input section -->
			<div id="snc-input-section" <?php echo $code ? 'style="display:none"' : ''; ?>>
				<p class="snc-input-label">
					<?php echo $code
						? esc_html__( 'Enter a new 6-digit Store Code:', 'sukunaat-order-manager' )
						: esc_html__( 'Enter your 6-digit Store Code:', 'sukunaat-order-manager' ); ?>
				</p>
				<div class="snc-input-row">
					<input
						type="number"
						id="snc-code-input"
						class="snc-code-input"
						placeholder="482719"
						maxlength="6"
						min="100000"
						max="999999"
						oninput="this.value=this.value.replace(/[^0-9]/g,'').slice(0,6)"
					>
					<button type="button" class="snc-btn-save" onclick="sncSaveCode()">
						💾 <?php esc_html_e( 'Save Code', 'sukunaat-order-manager' ); ?>
					</button>
					<?php if ( $code ) : ?>
					<button type="button" class="snc-btn-cancel" onclick="sncHideInput()">
						<?php esc_html_e( 'Cancel', 'sukunaat-order-manager' ); ?>
					</button>
					<?php endif; ?>
				</div>
				<div id="snc-input-err" class="snc-input-err" style="display:none"></div>
			</div>

			<!-- How to connect -->
			<div class="snc-how">
				<div class="snc-step"><span class="snc-num">1</span><?php esc_html_e( 'Copy the Store Code above', 'sukunaat-order-manager' ); ?></div>
				<div class="snc-arrow">→</div>
				<div class="snc-step"><span class="snc-num">2</span><?php esc_html_e( 'Open OrderPilot Pro app', 'sukunaat-order-manager' ); ?></div>
				<div class="snc-arrow">→</div>
				<div class="snc-step"><span class="snc-num">3</span><?php esc_html_e( 'Settings → Enter Store Code → Connect', 'sukunaat-order-manager' ); ?></div>
			</div>
		</div>
	</div>

	<!-- ── Enable toggle ────────────────────────────────────── -->
	<div class="snc-card">
		<div class="snc-card-title">⚙️ <?php esc_html_e( 'Settings', 'sukunaat-order-manager' ); ?></div>
		<div class="snc-card-body">
			<label class="snc-toggle-row">
				<div class="snc-toggle">
					<input type="checkbox" id="snc-toggle" <?php checked( $enabled ); ?> onchange="sncToggle(this.checked)">
					<span class="snc-slider"></span>
				</div>
				<div>
					<strong><?php esc_html_e( 'Enable push notifications', 'sukunaat-order-manager' ); ?></strong>
					<p id="snc-toggle-status">
						<?php echo $enabled
							? esc_html__( 'ON — staff will be alerted on every new order.', 'sukunaat-order-manager' )
							: esc_html__( 'OFF — no notifications will be sent.', 'sukunaat-order-manager' ); ?>
					</p>
				</div>
				<span id="snc-saving" style="display:none;font-size:18px;animation:snc-spin .7s linear infinite;display:none">⏳</span>
			</label>
		</div>
	</div>

	<!-- ── Last status ──────────────────────────────────────── -->
	<?php if ( $last_ok || $last_err ) : ?>
	<div class="snc-card">
		<div class="snc-card-title">📊 <?php esc_html_e( 'Last Notification', 'sukunaat-order-manager' ); ?></div>
		<div class="snc-card-body">
			<?php if ( $last_err ) : ?>
				<div class="snc-status snc-err">❌ <?php echo esc_html( $last_err ); ?></div>
			<?php elseif ( $last_ok ) : ?>
				<div class="snc-status snc-ok">✅ <?php esc_html_e( 'Sent at', 'sukunaat-order-manager' ); ?>: <?php echo esc_html( $last_ok ); ?></div>
			<?php endif; ?>
			<?php if ( $last_res ) : ?>
				<details style="margin-top:10px">
					<summary style="cursor:pointer;font-size:12px;color:#94a3b8"><?php esc_html_e( 'Server response', 'sukunaat-order-manager' ); ?></summary>
					<pre class="snc-pre"><?php echo esc_html( $last_res ); ?></pre>
				</details>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>

</div>

<style>
.snc-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 1px 4px rgba(15,23,42,.06);margin-bottom:18px;overflow:hidden}
.snc-card-title{padding:16px 22px;border-bottom:1px solid #f1f5f9;font-size:14.5px;font-weight:700;color:#0f172a}
.snc-card-body{padding:20px 22px}

.snc-code-display{display:flex;align-items:center;gap:18px;margin-bottom:16px;flex-wrap:wrap}
.snc-code-big{font-size:64px;font-weight:900;font-family:"Courier New",monospace;color:#4f46e5;letter-spacing:12px;line-height:1}
.snc-code-actions{display:flex;flex-direction:column;gap:8px}
.snc-btn-copy{background:#4f46e5;color:#fff;border:none;border-radius:8px;padding:10px 20px;font-size:13.5px;font-weight:700;cursor:pointer;transition:all .15s;font-family:inherit;white-space:nowrap}
.snc-btn-copy:hover{background:#4338ca;transform:translateY(-1px)}
.snc-btn-change{background:none;border:1.5px solid #e2e8f0;border-radius:8px;padding:8px 16px;font-size:13px;color:#64748b;cursor:pointer;transition:all .15s;font-family:inherit}
.snc-btn-change:hover{border-color:#4f46e5;color:#4f46e5}
.snc-copied-msg{font-size:13px;font-weight:600;color:#166534;margin-bottom:12px}

.snc-input-label{font-size:13px;color:#374151;font-weight:500;margin-bottom:10px}
.snc-input-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px}
.snc-code-input{height:52px;width:160px;font-size:28px;font-family:"Courier New",monospace;font-weight:700;letter-spacing:6px;text-align:center;border:2px solid #e2e8f0;border-radius:10px;outline:none;transition:border-color .15s;color:#4f46e5;padding:0 12px}
.snc-code-input:focus{border-color:#4f46e5;box-shadow:0 0 0 3px #eef2ff}
.snc-btn-save{background:#4f46e5;color:#fff;border:none;border-radius:8px;padding:12px 22px;font-size:14px;font-weight:700;cursor:pointer;transition:all .15s;font-family:inherit}
.snc-btn-save:hover{background:#4338ca}
.snc-btn-cancel{background:none;border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 16px;font-size:13px;color:#64748b;cursor:pointer;font-family:inherit}
.snc-input-err{font-size:12.5px;color:#991b1b;font-weight:500;margin-top:4px}

.snc-how{display:flex;align-items:center;gap:10px;margin-top:20px;padding-top:16px;border-top:1px solid #f1f5f9;flex-wrap:wrap}
.snc-step{display:flex;align-items:center;gap:8px;font-size:13px;color:#374151;font-weight:500}
.snc-num{width:22px;height:22px;background:#4f46e5;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;flex-shrink:0}
.snc-arrow{color:#c7d2fe;font-weight:700;font-size:16px}

.snc-toggle-row{display:flex;align-items:flex-start;gap:14px;cursor:pointer}
.snc-toggle-row strong{display:block;font-size:14px;color:#0f172a}
.snc-toggle-row p{font-size:12.5px;color:#64748b;margin:3px 0 0}
.snc-toggle{position:relative;width:44px;height:24px;flex-shrink:0;margin-top:2px}
.snc-toggle input{opacity:0;width:0;height:0;position:absolute}
.snc-slider{position:absolute;inset:0;background:#e2e8f0;border-radius:24px;cursor:pointer;transition:background .2s}
.snc-slider::before{content:'';position:absolute;left:3px;top:3px;width:18px;height:18px;background:#fff;border-radius:50%;transition:transform .2s;box-shadow:0 1px 3px rgba(0,0,0,.2)}
.snc-toggle input:checked+.snc-slider{background:#4f46e5}
.snc-toggle input:checked+.snc-slider::before{transform:translateX(20px)}

.snc-status{padding:11px 14px;border-radius:8px;font-size:13.5px;font-weight:500}
.snc-ok{background:#f0fdf4;color:#166534;border:1px solid #86efac}
.snc-err{background:#fff1f2;color:#991b1b;border:1px solid #fca5a5}
.snc-pre{margin-top:8px;font-size:11px;background:#f8fafc;padding:10px;border-radius:6px;overflow-x:auto;color:#475569;border:1px solid #e2e8f0}

@keyframes snc-spin{to{transform:rotate(360deg)}}
@media(max-width:600px){
	.snc-code-big{font-size:48px;letter-spacing:8px}
	.snc-how{flex-direction:column;align-items:flex-start}
	.snc-arrow{transform:rotate(90deg)}
}
</style>

<script>
var somNonce  = '<?php echo esc_js( wp_create_nonce( 'som_nonce' ) ); ?>';
var somAjax   = '<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>';

function sncCopy(code) {
	navigator.clipboard.writeText(code).then(function() {
		var m = document.getElementById('snc-copied-msg');
		m.style.display = 'block';
		setTimeout(function(){ m.style.display = 'none'; }, 2500);
	});
}

function sncShowInput() {
	document.querySelector('.snc-code-display').style.display = 'none';
	document.getElementById('snc-input-section').style.display = 'block';
	document.getElementById('snc-code-input').focus();
}

function sncHideInput() {
	document.querySelector('.snc-code-display').style.display = 'flex';
	document.getElementById('snc-input-section').style.display = 'none';
}

function sncSaveCode() {
	var code = document.getElementById('snc-code-input').value.replace(/[^0-9]/g,'').slice(0,6);
	var err  = document.getElementById('snc-input-err');

	if (code.length !== 6) {
		err.textContent = '<?php echo esc_js( __( 'Please enter exactly 6 digits.', 'sukunaat-order-manager' ) ); ?>';
		err.style.display = 'block';
		return;
	}
	err.style.display = 'none';

	fetch(somAjax, {
		method: 'POST',
		headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
		body: 'action=som_save_store_code&nonce=' + encodeURIComponent(somNonce) + '&code=' + encodeURIComponent(code),
	})
	.then(function(r){ return r.json(); })
	.then(function(res){
		if (res.success) {
			location.reload();
		} else {
			err.textContent = res.data.message || 'Error saving code.';
			err.style.display = 'block';
		}
	});
}

function sncToggle(enabled) {
	var saving = document.getElementById('snc-saving');
	var status = document.getElementById('snc-toggle-status');
	saving.style.display = 'inline';

	fetch(somAjax, {
		method: 'POST',
		headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
		body: 'action=som_toggle_notifications&nonce=' + encodeURIComponent(somNonce) + '&enabled=' + enabled,
	})
	.then(function(r){ return r.json(); })
	.then(function(res){
		saving.style.display = 'none';
		if (res.success) {
			status.textContent = res.data.enabled
				? '<?php echo esc_js( __( 'ON — staff will be alerted on every new order.', 'sukunaat-order-manager' ) ); ?>'
				: '<?php echo esc_js( __( 'OFF — no notifications will be sent.', 'sukunaat-order-manager' ) ); ?>';
		}
	})
	.catch(function(){ saving.style.display = 'none'; });
}

// Allow Enter key on input
document.addEventListener('DOMContentLoaded', function() {
	var inp = document.getElementById('snc-code-input');
	if (inp) inp.addEventListener('keydown', function(e){ if(e.key==='Enter') sncSaveCode(); });
});
</script>
