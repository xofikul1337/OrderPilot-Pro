<?php
/**
 * Reports template.
 *
 * @package SukunaatOrderManager
 */

defined( 'ABSPATH' ) || exit;

$range  = isset( $_GET['som_range'] ) ? sanitize_key( wp_unslash( $_GET['som_range'] ) ) : 'month';
$from   = isset( $_GET['som_from'] ) ? sanitize_text_field( wp_unslash( $_GET['som_from'] ) ) : '';
$to     = isset( $_GET['som_to'] ) ? sanitize_text_field( wp_unslash( $_GET['som_to'] ) ) : '';
$search = isset( $_GET['som_search'] ) ? sanitize_text_field( wp_unslash( $_GET['som_search'] ) ) : '';

if ( ! in_array( $range, [ 'all', 'today', 'month', 'custom' ], true ) ) {
	$range = 'month';
}

$report = \SukunaatOrderManager\Reports::instance()->summary(
	[
		'range'  => $range,
		'from'   => $from,
		'to'     => $to,
		'search' => $search,
	]
);
?>
<div class="wrap som-wrap som-reports-wrap">
	<div class="som-staff-header">
		<div>
			<h1><?php esc_html_e( 'Reports & Staff Management', 'sukunaat-order-manager' ); ?></h1>
			<p><?php esc_html_e( 'Track sales, cancelled orders, and which WordPress user confirmed each order.', 'sukunaat-order-manager' ); ?></p>
		</div>
		<a class="som-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=sukunaat-order-manager' ) ); ?>">
			<?php esc_html_e( 'Back to Orders', 'sukunaat-order-manager' ); ?>
		</a>
	</div>

	<form class="som-report-filters" method="get">
		<input type="hidden" name="page" value="sukunaat-order-manager-reports">
		<select name="som_range">
			<option value="all" <?php selected( $range, 'all' ); ?>><?php esc_html_e( 'All Time', 'sukunaat-order-manager' ); ?></option>
			<option value="today" <?php selected( $range, 'today' ); ?>><?php esc_html_e( 'Today', 'sukunaat-order-manager' ); ?></option>
			<option value="month" <?php selected( $range, 'month' ); ?>><?php esc_html_e( 'This Month', 'sukunaat-order-manager' ); ?></option>
			<option value="custom" <?php selected( $range, 'custom' ); ?>><?php esc_html_e( 'Custom Date', 'sukunaat-order-manager' ); ?></option>
		</select>
		<input type="date" name="som_from" value="<?php echo esc_attr( $from ); ?>">
		<input type="date" name="som_to" value="<?php echo esc_attr( $to ); ?>">
		<input type="search" name="som_search" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search staff name or email', 'sukunaat-order-manager' ); ?>">
		<button class="som-btn-primary" type="submit"><?php esc_html_e( 'Filter', 'sukunaat-order-manager' ); ?></button>
	</form>

	<div class="som-report-grid">
		<?php foreach ( $report['cards'] as $card ) : ?>
			<div class="som-report-card">
				<span><?php echo esc_html( $card['label'] ); ?></span>
				<strong><?php echo wp_kses_post( $card['value'] ); ?></strong>
				<small><?php echo esc_html( $card['note'] ); ?></small>
			</div>
		<?php endforeach; ?>
	</div>

	<div class="som-staff-panel som-report-panel">
		<h2><?php esc_html_e( 'Staff Confirmed Orders', 'sukunaat-order-manager' ); ?></h2>
		<?php if ( empty( $report['staff'] ) ) : ?>
			<p class="som-staff-empty"><?php esc_html_e( 'No confirmed order activity found for this filter.', 'sukunaat-order-manager' ); ?></p>
		<?php else : ?>
			<table class="som-report-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Staff', 'sukunaat-order-manager' ); ?></th>
						<th><?php esc_html_e( 'Email', 'sukunaat-order-manager' ); ?></th>
						<th><?php esc_html_e( 'Confirmed Orders', 'sukunaat-order-manager' ); ?></th>
						<th><?php esc_html_e( 'Details', 'sukunaat-order-manager' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $report['staff'] as $staff ) : ?>
						<tr>
							<td><?php echo esc_html( $staff['name'] ); ?></td>
							<td><?php echo esc_html( $staff['email'] ); ?></td>
							<td><strong><?php echo esc_html( $staff['confirmed'] ); ?></strong></td>
							<td>
								<button
									type="button"
									class="som-report-view-details"
									data-user-id="<?php echo esc_attr( $staff['id'] ); ?>"
									data-name="<?php echo esc_attr( $staff['name'] ); ?>"
								>
									<?php esc_html_e( 'View Details', 'sukunaat-order-manager' ); ?>
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
</div>

<div class="som-report-drawer-overlay" id="som-report-drawer-overlay" style="display:none;"></div>
<aside class="som-report-drawer" id="som-report-drawer" aria-hidden="true">
	<div class="som-drawer-head">
		<div>
			<span class="som-drawer-kicker"><?php esc_html_e( 'Staff History', 'sukunaat-order-manager' ); ?></span>
			<h2 id="som-report-drawer-title"><?php esc_html_e( 'Activity Details', 'sukunaat-order-manager' ); ?></h2>
		</div>
		<button type="button" class="som-drawer-close" id="som-report-drawer-close" aria-label="<?php esc_attr_e( 'Close staff history', 'sukunaat-order-manager' ); ?>">×</button>
	</div>
	<div class="som-report-drawer-body">
		<div class="som-report-drawer-filter">
			<label>
				<span><?php esc_html_e( 'Date', 'sukunaat-order-manager' ); ?></span>
				<input type="date" id="som-report-activity-date" value="<?php echo esc_attr( wp_date( 'Y-m-d' ) ); ?>">
			</label>
		</div>
		<div id="som-report-activity-list" class="som-report-activity-list">
			<p class="som-staff-empty"><?php esc_html_e( 'Select a staff member to view history.', 'sukunaat-order-manager' ); ?></p>
		</div>
	</div>
</aside>
