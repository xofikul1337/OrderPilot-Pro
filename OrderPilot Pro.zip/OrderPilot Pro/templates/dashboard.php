<?php
/**
 * Dashboard template.
 *
 * @package SukunaatOrderManager
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap som-wrap">

	<!-- ── Header ─────────────────────────────────────────────────────── -->
	<div class="som-header">
		<div class="som-header-inner">

			<!-- Logo + Branding -->
			<div class="som-logo">
				<div class="som-logo-icon">
					<span class="dashicons dashicons-list-view"></span>
				</div>
				<div class="som-logo-text">
					<h1><?php esc_html_e( 'OrderPilot Pro', 'sukunaat-order-manager' ); ?></h1>
					<p class="som-subtitle"><?php esc_html_e( 'WooCommerce Order Management Dashboard', 'sukunaat-order-manager' ); ?></p>
				</div>
			</div>

			<!-- Stats + Dev credit -->
			<div class="som-header-right">
				<!-- Total orders stat -->
				<div class="som-stat-box">
					<span class="som-stat-num" id="som-total-count">—</span>
					<span class="som-stat-label"><?php esc_html_e( 'Orders', 'sukunaat-order-manager' ); ?></span>
				</div>

				<!-- Date stat -->
				<div class="som-stat-box som-stat-box--date">
					<span class="som-stat-num" id="som-today-count">—</span>
					<span class="som-stat-label"><?php esc_html_e( 'Today', 'sukunaat-order-manager' ); ?></span>
				</div>

				<!-- Developer credit -->
				<div class="som-dev-credit">
					<span class="som-dev-label"><?php esc_html_e( 'Developed by', 'sukunaat-order-manager' ); ?></span>
					<a class="som-dev-name" href="https://xofikul.is-a.dev/" target="_blank" rel="noopener noreferrer">
						<span class="som-dev-avatar">SI</span>
						Shofikul Islam
					</a>
				</div>
			</div>
		</div>
	</div>

	<!-- ── Status Tabs ─────────────────────────────────────────────────── -->
	<section class="som-analytics" aria-label="<?php esc_attr_e( 'Order analytics overview', 'sukunaat-order-manager' ); ?>">
		<div class="som-metric-grid">
			<div class="som-metric-card som-metric-card--primary">
				<span class="som-metric-label"><?php esc_html_e( 'Today Sales', 'sukunaat-order-manager' ); ?></span>
				<strong class="som-metric-value" id="som-metric-today-sales">--</strong>
				<span class="som-metric-sub" id="som-metric-today-sales-sub"><?php esc_html_e( 'Loading...', 'sukunaat-order-manager' ); ?></span>
			</div>
			<div class="som-metric-card">
				<span class="som-metric-label"><?php esc_html_e( 'This Month', 'sukunaat-order-manager' ); ?></span>
				<strong class="som-metric-value" id="som-metric-month-sales">--</strong>
				<span class="som-metric-sub" id="som-metric-month-sales-sub"><?php esc_html_e( 'Loading...', 'sukunaat-order-manager' ); ?></span>
			</div>
			<div class="som-metric-card">
				<span class="som-metric-label"><?php esc_html_e( 'Pending Amount', 'sukunaat-order-manager' ); ?></span>
				<strong class="som-metric-value" id="som-metric-pending-amount">--</strong>
				<span class="som-metric-sub" id="som-metric-pending-amount-sub"><?php esc_html_e( 'Loading...', 'sukunaat-order-manager' ); ?></span>
			</div>
			<div class="som-metric-card">
				<span class="som-metric-label"><?php esc_html_e( 'Avg Order Today', 'sukunaat-order-manager' ); ?></span>
				<strong class="som-metric-value" id="som-metric-avg-order">--</strong>
				<span class="som-metric-sub" id="som-metric-avg-order-sub"><?php esc_html_e( 'Loading...', 'sukunaat-order-manager' ); ?></span>
			</div>
		</div>

		<div class="som-chart-panel">
			<div class="som-chart-head">
				<div>
					<h2><?php esc_html_e( 'Sales Trend', 'sukunaat-order-manager' ); ?></h2>
					<p><?php esc_html_e( 'Last 7 days active order revenue', 'sukunaat-order-manager' ); ?></p>
				</div>
				<span class="som-chart-total" id="som-chart-total">--</span>
			</div>
			<div class="som-chart-bars" id="som-sales-chart" aria-live="polite">
				<div class="som-chart-empty"><?php esc_html_e( 'Loading chart...', 'sukunaat-order-manager' ); ?></div>
			</div>
		</div>
	</section>

	<div class="som-tabs-wrap">
		<div class="som-tabs" id="som-tabs">
			<button class="som-tab is-active" data-status="all">
				<span class="som-tab-label"><?php esc_html_e( 'All Orders', 'sukunaat-order-manager' ); ?></span>
				<span class="som-tab-badge" id="som-count-all">—</span>
			</button>
			<button class="som-tab som-tab--pending" data-status="pending">
				<span class="som-tab-dot"></span>
				<span class="som-tab-label"><?php esc_html_e( 'Pending', 'sukunaat-order-manager' ); ?></span>
				<span class="som-tab-badge" id="som-count-pending">—</span>
			</button>
			<button class="som-tab som-tab--on-hold" data-status="on-hold">
				<span class="som-tab-dot"></span>
				<span class="som-tab-label"><?php esc_html_e( 'On Hold', 'sukunaat-order-manager' ); ?></span>
				<span class="som-tab-badge" id="som-count-on-hold">—</span>
			</button>
			<button class="som-tab som-tab--courier" data-status="sent-to-courier">
				<span class="som-tab-dot"></span>
				<span class="som-tab-label"><?php esc_html_e( 'Sent To Courier', 'sukunaat-order-manager' ); ?></span>
				<span class="som-tab-badge" id="som-count-sent-to-courier">—</span>
			</button>
			<button class="som-tab som-tab--confirmed" data-status="confirmed">
				<span class="som-tab-dot"></span>
				<span class="som-tab-label"><?php esc_html_e( 'Confirmed', 'sukunaat-order-manager' ); ?></span>
				<span class="som-tab-badge" id="som-count-confirmed">—</span>
			</button>
			<button class="som-tab som-tab--cancelled" data-status="cancelled">
				<span class="som-tab-dot"></span>
				<span class="som-tab-label"><?php esc_html_e( 'Cancelled', 'sukunaat-order-manager' ); ?></span>
				<span class="som-tab-badge" id="som-count-cancelled">—</span>
			</button>
		</div>
	</div>

	<!-- ── Toolbar ─────────────────────────────────────────────────────── -->
	<div class="som-toolbar">

		<button type="button" class="som-btn-primary som-create-order-open" id="som-create-order-open">
			<?php esc_html_e( 'Create Order', 'sukunaat-order-manager' ); ?>
		</button>

		<!-- Search -->
		<div class="som-search-wrap">
			<svg class="som-search-icon" viewBox="0 0 20 20" fill="none">
				<circle cx="9" cy="9" r="6" stroke="currentColor" stroke-width="1.8"/>
				<path d="M13.5 13.5L17 17" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
			</svg>
			<input
				type="search"
				id="som-search"
				class="som-search-input"
				placeholder="<?php esc_attr_e( 'Search by name, phone or order #…', 'sukunaat-order-manager' ); ?>"
				autocomplete="off"
			>
			<button class="som-search-clear" id="som-search-clear" style="display:none">✕</button>
		</div>

		<!-- Date Filter -->
		<div class="som-date-filter">
			<div class="som-date-btns">
				<button class="som-date-btn is-active" data-range="all"><?php esc_html_e( 'All Time', 'sukunaat-order-manager' ); ?></button>
				<button class="som-date-btn" data-range="today"><?php esc_html_e( 'Today', 'sukunaat-order-manager' ); ?></button>
				<button class="som-date-btn" data-range="yesterday"><?php esc_html_e( 'Yesterday', 'sukunaat-order-manager' ); ?></button>
				<button class="som-date-btn" data-range="week"><?php esc_html_e( 'This Week', 'sukunaat-order-manager' ); ?></button>
				<button class="som-date-btn" data-range="month"><?php esc_html_e( 'This Month', 'sukunaat-order-manager' ); ?></button>
			</div>
			<div class="som-date-custom">
				<input type="date" id="som-date-from" class="som-date-input" placeholder="From">
				<span class="som-date-sep">→</span>
				<input type="date" id="som-date-to"   class="som-date-input" placeholder="To">
				<button id="som-date-apply" class="som-btn-primary-sm"><?php esc_html_e( 'Apply', 'sukunaat-order-manager' ); ?></button>
			</div>
		</div>

		<!-- Bulk bar (hidden until rows selected) -->
		<div class="som-bulk-bar" id="som-bulk-bar" style="display:none;">
			<span class="som-bulk-count">
				<span id="som-selected-count">0</span> <?php esc_html_e( 'selected', 'sukunaat-order-manager' ); ?>
			</span>
			<div class="som-bulk-actions">
				<select id="som-bulk-action-select" class="som-bulk-select">
					<option value=""><?php esc_html_e( '— Bulk Action —', 'sukunaat-order-manager' ); ?></option>
					<optgroup label="<?php esc_attr_e( 'Change Status', 'sukunaat-order-manager' ); ?>">
						<option value="status:confirm"><?php esc_html_e( '✅ Confirm Order', 'sukunaat-order-manager' ); ?></option>
						<option value="status:on-hold"><?php esc_html_e( '⏸ On Hold', 'sukunaat-order-manager' ); ?></option>
						<option value="status:sent-to-courier"><?php esc_html_e( '🚚 Sent To Courier', 'sukunaat-order-manager' ); ?></option>
						<option value="status:cancel"><?php esc_html_e( '✖ Cancel Order', 'sukunaat-order-manager' ); ?></option>
					</optgroup>
					<optgroup label="<?php esc_attr_e( 'Other', 'sukunaat-order-manager' ); ?>">
						<option value="delete"><?php esc_html_e( '🗑 Delete Orders', 'sukunaat-order-manager' ); ?></option>
					</optgroup>
				</select>
				<button id="som-bulk-apply"  class="som-btn-primary"><?php esc_html_e( 'Apply', 'sukunaat-order-manager' ); ?></button>
				<button id="som-bulk-cancel" class="som-btn-ghost"><?php esc_html_e( 'Clear', 'sukunaat-order-manager' ); ?></button>
			</div>
		</div>
	</div>

	<!-- ── Table Card ──────────────────────────────────────────────────── -->
	<div class="som-card">
		<div class="som-table-wrap">
			<table class="som-table" id="som-orders-table">
				<thead>
					<tr>
						<th class="som-col-cb">
							<label class="som-checkbox-label">
								<input type="checkbox" id="som-check-all">
								<span class="som-checkmark"></span>
							</label>
						</th>
						<th class="som-col-name"><?php    esc_html_e( 'Customer', 'sukunaat-order-manager' ); ?></th>
						<th class="som-col-phone"><?php   esc_html_e( 'Phone',    'sukunaat-order-manager' ); ?></th>
						<th class="som-col-address"><?php esc_html_e( 'Address',  'sukunaat-order-manager' ); ?></th>
						<th class="som-col-products"><?php esc_html_e( 'Product', 'sukunaat-order-manager' ); ?></th>
						<th class="som-col-note"><?php    esc_html_e( 'Note',     'sukunaat-order-manager' ); ?></th>
						<th class="som-col-status"><?php  esc_html_e( 'Status',   'sukunaat-order-manager' ); ?></th>
						<th class="som-col-actions"><?php esc_html_e( 'Actions',  'sukunaat-order-manager' ); ?></th>
					</tr>
				</thead>
				<tbody id="som-orders-tbody">
					<tr>
						<td colspan="8" class="som-loading-cell">
							<div class="som-spinner"></div>
							<p><?php esc_html_e( 'Loading orders…', 'sukunaat-order-manager' ); ?></p>
						</td>
					</tr>
				</tbody>
			</table>
		</div>

		<!-- Pagination -->
		<div class="som-pagination" id="som-pagination">
			<div class="som-page-info" id="som-page-info"></div>
			<div class="som-page-btns" id="som-page-btns"></div>
		</div>
	</div>

	<!-- ── Watermark ──────────────────────────────────────────────────── -->
	<div class="som-watermark">
		<span class="som-watermark-icon">⚡</span>
		<?php esc_html_e( 'Developed by', 'sukunaat-order-manager' ); ?>
		<a href="https://xofikul.is-a.dev/" target="_blank" rel="noopener noreferrer">Shofikul Islam</a>
	</div>

</div><!-- .som-wrap -->

<!-- Order detail drawer -->
<div class="som-drawer-overlay" id="som-drawer-overlay" style="display:none;"></div>
<aside class="som-order-drawer" id="som-order-drawer" aria-hidden="true">
	<div class="som-drawer-head">
		<div>
			<span class="som-drawer-kicker"><?php esc_html_e( 'Order Details', 'sukunaat-order-manager' ); ?></span>
			<h2 id="som-drawer-title">#--</h2>
		</div>
		<button type="button" class="som-drawer-close" id="som-drawer-close" aria-label="<?php esc_attr_e( 'Close order details', 'sukunaat-order-manager' ); ?>">×</button>
	</div>
	<div class="som-drawer-body" id="som-drawer-body">
		<div class="som-drawer-loading">
			<div class="som-spinner"></div>
			<p><?php esc_html_e( 'Loading order details...', 'sukunaat-order-manager' ); ?></p>
		</div>
	</div>
</aside>

<!-- Create order modal -->
<div class="som-create-modal-overlay" id="som-create-modal-overlay" style="display:none;">
	<div class="som-create-modal">
		<div class="som-create-head">
			<div>
				<span><?php esc_html_e( 'Manual Order', 'sukunaat-order-manager' ); ?></span>
				<h2><?php esc_html_e( 'Create Confirmed Order', 'sukunaat-order-manager' ); ?></h2>
			</div>
			<button type="button" id="som-create-close" class="som-drawer-close" aria-label="<?php esc_attr_e( 'Close create order modal', 'sukunaat-order-manager' ); ?>">×</button>
		</div>
		<form id="som-create-order-form" class="som-create-form">
			<div class="som-create-grid">
				<label>
					<span><?php esc_html_e( 'Customer Name', 'sukunaat-order-manager' ); ?></span>
					<input type="text" id="som-create-name" required>
				</label>
				<label>
					<span><?php esc_html_e( 'Phone', 'sukunaat-order-manager' ); ?></span>
					<input type="text" id="som-create-phone" required>
				</label>
			</div>
			<label>
				<span><?php esc_html_e( 'Address', 'sukunaat-order-manager' ); ?></span>
				<textarea id="som-create-address" rows="2" required></textarea>
			</label>
			<label class="som-product-search-wrap">
				<span><?php esc_html_e( 'Product', 'sukunaat-order-manager' ); ?></span>
				<input type="search" id="som-create-product-search" placeholder="<?php esc_attr_e( 'Search product...', 'sukunaat-order-manager' ); ?>" autocomplete="off" required>
				<input type="hidden" id="som-create-product-id">
				<div class="som-product-results" id="som-product-results"></div>
			</label>
			<div class="som-create-grid">
				<label>
					<span><?php esc_html_e( 'Quantity', 'sukunaat-order-manager' ); ?></span>
					<input type="number" id="som-create-quantity" min="1" value="1" required>
				</label>
				<label>
					<span><?php esc_html_e( 'Internal Note', 'sukunaat-order-manager' ); ?></span>
					<input type="text" id="som-create-note" placeholder="<?php esc_attr_e( 'Optional', 'sukunaat-order-manager' ); ?>">
				</label>
			</div>
			<div class="som-create-selected" id="som-create-selected" style="display:none;"></div>
			<div class="som-create-actions">
				<button type="submit" class="som-btn-primary"><?php esc_html_e( 'Create & Confirm', 'sukunaat-order-manager' ); ?></button>
				<button type="button" class="som-btn-ghost" id="som-create-cancel"><?php esc_html_e( 'Cancel', 'sukunaat-order-manager' ); ?></button>
			</div>
		</form>
	</div>
</div>

<!-- Toast -->
<div class="som-toast-container" id="som-toast-container" aria-live="polite"></div>

<!-- Confirm modal -->
<div class="som-modal-overlay" id="som-modal-overlay" style="display:none;">
	<div class="som-modal">
		<div class="som-modal-icon" id="som-modal-icon">🗑</div>
		<h3 id="som-modal-title"></h3>
		<p  id="som-modal-body"></p>
		<div class="som-modal-actions">
			<button id="som-modal-confirm" class="som-btn-danger"><?php esc_html_e( 'Yes, Delete', 'sukunaat-order-manager' ); ?></button>
			<button id="som-modal-cancel"  class="som-btn-ghost"><?php esc_html_e( 'Cancel', 'sukunaat-order-manager' ); ?></button>
		</div>
	</div>
</div>
