/**
 * OrderPilot Pro for WooCommerce — Admin JS v1.1.0
 */
/* global somData, jQuery */
(function ($) {
	'use strict';

	var state = {
		page:     1,
		pages:    1,
		total:    0,
		search:   '',
		status:   'all',
		range:    'all',
		dateFrom: '',
		dateTo:   '',
		assignedTo: -1,
		loading:  false,
		timer:    null,
		productTimer: null,
	};

	var $tbody    = $('#som-orders-tbody');
	var $pageInfo = $('#som-page-info');
	var $pageBtns = $('#som-page-btns');
	var $search   = $('#som-search');
	var $clearBtn = $('#som-search-clear');
	var $totalNum = $('#som-total-count');
	var $todayNum = $('#som-today-count');
	var $bulkBar  = $('#som-bulk-bar');
	var $selCount = $('#som-selected-count');
	var $checkAll = $('#som-check-all');
	var $overlay  = $('#som-modal-overlay');
	var $chart    = $('#som-sales-chart');
	var $drawer   = $('#som-order-drawer');
	var $drawerOverlay = $('#som-drawer-overlay');
	var $drawerBody = $('#som-drawer-body');
	var reportStaffId = 0;
	var autoOpenOrderId = parseInt(somData.openOrderId || 0, 10);

	$(document).ready(function () {
		loadCounts();
		loadMetrics();
		fetchOrders();
		bindUI();
	});

	// ── Bind events ────────────────────────────────────────────────────────
	function bindUI() {

		// Status tabs
		$(document).on('click', '.som-tab', function () {
			$('.som-tab').removeClass('is-active');
			$(this).addClass('is-active');
			state.status = $(this).data('status');
			state.page   = 1;
			clearBulk();
			fetchOrders();
		});

		// Quick date range buttons
		$(document).on('click', '.som-date-btn', function () {
			$('.som-date-btn').removeClass('is-active');
			$(this).addClass('is-active');
			state.range   = $(this).data('range');
			state.dateFrom = '';
			state.dateTo   = '';
			state.page     = 1;
			$('#som-date-from, #som-date-to').val('');
			fetchOrders();
		});

		// Custom date apply
		$('#som-date-apply').on('click', function () {
			var from = $('#som-date-from').val();
			var to   = $('#som-date-to').val();
			if (!from && !to) { toast('Please select at least one date.', 'error'); return; }
			$('.som-date-btn').removeClass('is-active');
			state.range    = 'custom';
			state.dateFrom = from;
			state.dateTo   = to;
			state.page     = 1;
			fetchOrders();
		});

		// Search
		$search.on('input', function () {
			var val = $(this).val().trim();
			$clearBtn.toggle(val.length > 0);
			clearTimeout(state.timer);
			state.timer = setTimeout(function () {
				state.search = val;
				state.page   = 1;
				fetchOrders();
			}, 350);
		});

		$clearBtn.on('click', function () {
			$search.val('').trigger('input').focus();
		});

		// Select-all
		$checkAll.on('change', function () {
			var chk = $(this).prop('checked');
			$tbody.find('.som-row-check').prop('checked', chk);
			$tbody.find('tr[data-order-id]').toggleClass('is-selected', chk);
			syncBulkBar();
		});

		// Row checkboxes
		$tbody.on('change', '.som-row-check', function () {
			$(this).closest('tr').toggleClass('is-selected', $(this).prop('checked'));
			var t = $tbody.find('.som-row-check').length;
			var c = $tbody.find('.som-row-check:checked').length;
			$checkAll.prop('indeterminate', c > 0 && c < t).prop('checked', c === t && t > 0);
			syncBulkBar();
		});

		$tbody.on('click', 'tr[data-order-id]', function (e) {
			if ($(e.target).closest('button, a, input, label, select, textarea, .som-action-dropdown').length) return;
			openOrderDrawer($(this).data('order-id'));
		});

		// Bulk apply
		$('#som-bulk-apply').on('click', function () {
			var action = $('#som-bulk-action-select').val();
			var ids    = getSelectedIds();
			if (!action) { toast('Please select an action.', 'error'); return; }
			if (!ids.length) { toast('No orders selected.', 'error'); return; }
			if (action === 'delete') {
				openModal('🗑', 'Delete ' + ids.length + ' order' + (ids.length > 1 ? 's' : '') + '?',
					'This action cannot be undone.',
					function () { doBulkDelete(ids); });
			} else if (action.startsWith('status:')) {
				doBulkStatus(ids, action.replace('status:', ''));
			}
		});

		$('#som-bulk-cancel').on('click', clearBulk);

		// Notes
		$tbody.on('click', '.som-btn-add-note',    function () { showEditor($(this).closest('tr'), ''); });
		$tbody.on('click', '.som-btn-edit-note',   function () {
			var $r = $(this).closest('tr');
			showEditor($r, $r.find('.som-note-text').text().trim());
		});
		$tbody.on('click', '.som-btn-delete-note', function () {
			var $r = $(this).closest('tr');
			openModal('🗑', 'Delete note?', 'The note will be permanently removed.', function () {
				doDeleteNote($r, $r.data('order-id'));
			});
		});
		$tbody.on('click', '.som-btn-save-note',   function () {
			var $r = $(this).closest('tr');
			doSaveNote($r, $r.data('order-id'), $r.find('.som-note-input').val());
		});
		$tbody.on('click', '.som-btn-cancel-note', function () { hideEditor($(this).closest('tr')); });

		// Action dropdown
		$tbody.on('click', '.som-action-toggle', function (e) {
			e.stopPropagation();
			var $m   = $(this).siblings('.som-action-menu');
			var open = $m.hasClass('is-open');
			closeDropdowns();
			if (!open) { $m.addClass('is-open'); $(this).attr('aria-expanded', 'true'); }
		});
		$tbody.on('click', '.som-action-menu button', function () {
			var $r = $(this).closest('tr');
			closeDropdowns();
			doUpdateStatus($r, $r.data('order-id'), $(this).data('action'));
		});

		$(document).on('click', function (e) {
			if (!$(e.target).closest('.som-action-dropdown').length) closeDropdowns();
		});

		// Modal
		$('#som-modal-cancel').on('click', closeModal);
		$overlay.on('click', function (e) { if ($(e.target).is($overlay)) closeModal(); });

		$('#som-drawer-close').on('click', closeOrderDrawer);
		$drawerOverlay.on('click', closeOrderDrawer);
		$drawerBody.on('click', '.som-drawer-status-action', function () {
			var orderId = $(this).data('order-id');
			var action = $(this).data('action');
			doUpdateStatus($tbody.find('tr[data-order-id="' + orderId + '"]'), orderId, action);
		});
		$(document).on('keydown', function (e) { if (e.key === 'Escape') closeOrderDrawer(); });

		$('#som-create-order-open').on('click', openCreateModal);
		$('#som-create-close, #som-create-cancel').on('click', closeCreateModal);
		$('#som-create-modal-overlay').on('click', function (e) {
			if ($(e.target).is('#som-create-modal-overlay')) closeCreateModal();
		});
		$('#som-create-product-search').on('input', handleProductSearch);
		$('#som-product-results').on('click', '.som-product-result', function () {
			selectProduct($(this).data('id'), $(this).data('name'), $(this).data('price'));
		});
		$('#som-create-order-form').on('submit', submitCreateOrder);

		$(document).on('click', '.som-report-view-details', function () {
			reportStaffId = parseInt($(this).data('user-id'), 10);
			openReportDrawer($(this).data('name') || 'Staff');
		});
		$('#som-report-drawer-close, #som-report-drawer-overlay').on('click', closeReportDrawer);
		$('#som-report-activity-date').on('change', function () {
			if (reportStaffId) loadReportActivity();
		});
	}

	// ── AJAX: counts ───────────────────────────────────────────────────────
	function loadCounts() {
		$.post(somData.ajaxUrl, { action: 'som_get_counts', nonce: somData.nonce }, function (res) {
			if (!res.success) return;
			setCounts(res.data);
		});
	}

	function setCounts(c) {
		if (!c) return;
		$.each(c, function (s, n) {
			if (s === 'today') { $todayNum.text(n); }
			else { $('#som-count-' + s).text(n); }
		});
	}

	function loadMetrics() {
		$.post(somData.ajaxUrl, { action: 'som_get_metrics', nonce: somData.nonce }, function (res) {
			if (!res.success || !res.data) return;
			setMetrics(res.data.cards || {});
			renderSalesChart(res.data.chart || [], res.data.chart_total || '');
		});
	}

	function setMetrics(cards) {
		setMetric('today-sales', cards.today_sales);
		setMetric('month-sales', cards.month_sales);
		setMetric('pending-amount', cards.pending_amount);
		setMetric('avg-order', cards.avg_order);
	}

	function setMetric(key, data) {
		if (!data) return;
		$('#som-metric-' + key).html(data.value || '--');
		$('#som-metric-' + key + '-sub').text(data.sub_label || '');
	}

	function renderSalesChart(items, totalFormatted) {
		if (!$chart.length) return;
		if (!items.length) {
			$chart.html('<div class="som-chart-empty">No sales data yet.</div>');
			$('#som-chart-total').html(totalFormatted || '--');
			return;
		}

		var max = 0;
		items.forEach(function (item) { max = Math.max(max, parseFloat(item.amount) || 0); });
		var html = '';

		items.forEach(function (item) {
			var amount = parseFloat(item.amount) || 0;
			var height = max > 0 ? Math.max(8, Math.round((amount / max) * 100)) : 8;
			html += '<div class="som-chart-item" title="' + esc(item.amount_formatted || '') + '">' +
				'<div class="som-chart-amount">' + esc(item.amount_formatted || '0') + '</div>' +
				'<div class="som-chart-track"><span class="som-chart-bar" style="height:' + height + '%"></span></div>' +
				'<div class="som-chart-label">' + esc(item.label || '') + '</div>' +
				'<div class="som-chart-orders">' + esc(item.orders || 0) + ' orders</div>' +
			'</div>';
		});

		$chart.html(html);
		$('#som-chart-total').html(totalFormatted || '--');
	}

	function openOrderDrawer(orderId) {
		if (!orderId) return;
		$drawerOverlay.fadeIn(120);
		$drawer.addClass('is-open').attr('aria-hidden', 'false');
		$('#som-drawer-title').text('#' + orderId);
		$drawerBody.html('<div class="som-drawer-loading"><div class="som-spinner"></div><p>Loading order details...</p></div>');

		$.post(somData.ajaxUrl, { action: 'som_get_order_detail', nonce: somData.nonce, order_id: orderId }, function (res) {
			if (!res.success || !res.data) {
				$drawerBody.html('<div class="som-drawer-error">' + esc(somData.i18n.error) + '</div>');
				return;
			}
			renderOrderDrawer(res.data);
		}).fail(function () {
			$drawerBody.html('<div class="som-drawer-error">' + esc(somData.i18n.error) + '</div>');
		});
	}

	function closeOrderDrawer() {
		if (!$drawer.hasClass('is-open')) return;
		$drawer.removeClass('is-open').attr('aria-hidden', 'true');
		$drawerOverlay.fadeOut(120);
	}

	function renderOrderDrawer(data) {
		$('#som-drawer-title').text('#' + (data.order_number || data.id));

		var html = '<div class="som-drawer-summary">' +
			'<div><span>Customer</span><strong>' + esc(data.name || 'Guest') + '</strong></div>' +
			'<div><span>Total</span><strong>' + (data.total || '--') + '</strong></div>' +
			'<div><span>Status</span><strong class="som-status-badge som-status--' + esc(data.status || '') + '">' + esc(data.status_label || '') + '</strong></div>' +
		'</div>';

		html += '<div class="som-intel-grid">' +
			intelCard('Total Orders', data.intelligence && data.intelligence.orders) +
			intelCard('Total Spent', data.intelligence && data.intelligence.total_spent, true) +
			intelCard('Cancelled', data.intelligence && data.intelligence.cancelled) +
			intelCard('Same Phone', data.intelligence && data.intelligence.duplicate_phone) +
		'</div>';

		html += '<div class="som-drawer-assign"><span>Handled By</span><strong>' + esc(data.assigned_name || 'Not handled yet') + '</strong></div>';

		html += '<div class="som-drawer-quick-actions">' +
			'<button class="som-drawer-status-action" data-order-id="' + escAttr(data.id) + '" data-action="confirm">Confirm</button>' +
			'<button class="som-drawer-status-action" data-order-id="' + escAttr(data.id) + '" data-action="pending">Pending</button>' +
			'<button class="som-drawer-status-action" data-order-id="' + escAttr(data.id) + '" data-action="on-hold">On Hold</button>' +
			'<button class="som-drawer-status-action" data-order-id="' + escAttr(data.id) + '" data-action="sent-to-courier">Sent To Courier</button>' +
			'<button class="som-drawer-status-action is-danger" data-order-id="' + escAttr(data.id) + '" data-action="cancel">Cancel</button>' +
		'</div>';

		if (data.intelligence && parseInt(data.intelligence.cancelled, 10) > 0) {
			html += '<div class="som-risk-note">This customer has cancelled orders before. Review carefully before sending to courier.</div>';
		}
		if (data.intelligence && parseInt(data.intelligence.duplicate_phone, 10) > 0) {
			html += '<div class="som-risk-note som-risk-note--info">Same phone number appears on other orders.</div>';
		}

		html += drawerSection('Customer Info',
			infoRow('Phone', data.phone ? '<a href="tel:' + escAttr(data.phone) + '">' + esc(data.phone) + '</a>' : '--') +
			infoRow('Email', data.email ? '<a href="mailto:' + escAttr(data.email) + '">' + esc(data.email) + '</a>' : '--') +
			infoRow('Address', esc(data.address || '--')) +
			infoRow('Payment', esc(data.payment_method || '--')) +
			infoRow('Created', esc(data.date || '--'))
		);

		html += drawerSection('Products', renderItems(data.items || []));

		if (data.note) {
			html += drawerSection('Internal Note', '<p class="som-drawer-note">' + esc(data.note) + '</p>');
		}

		html += drawerSection('Activity Timeline', renderActivity(data.activity || []));
		$drawerBody.html(html);
	}

	function openCreateModal() {
		$('#som-create-modal-overlay').fadeIn(140);
		$('#som-create-name').focus();
	}

	function closeCreateModal() {
		$('#som-create-modal-overlay').fadeOut(120);
		$('#som-create-order-form')[0].reset();
		$('#som-create-product-id').val('');
		$('#som-product-results').empty().hide();
		$('#som-create-selected').hide().empty();
	}

	function handleProductSearch() {
		var term = $(this).val().trim();
		$('#som-create-product-id').val('');
		$('#som-create-selected').hide().empty();
		clearTimeout(state.productTimer);
		if (term.length < 2) {
			$('#som-product-results').empty().hide();
			return;
		}
		state.productTimer = setTimeout(function () {
			$.post(somData.ajaxUrl, { action: 'som_search_products', nonce: somData.nonce, term: term }, function (res) {
				if (!res.success || !res.data.length) {
					$('#som-product-results').html('<div class="som-product-no-result">No products found.</div>').show();
					return;
				}
				var html = res.data.map(function (product) {
					return '<button type="button" class="som-product-result" data-id="' + escAttr(product.id) + '" data-name="' + escAttr(product.name) + '" data-price="' + escAttr(product.price) + '">' +
						'<strong>' + esc(product.name) + '</strong><span>' + (product.sku ? esc(product.sku) + ' - ' : '') + product.price + '</span></button>';
				}).join('');
				$('#som-product-results').html(html).show();
			});
		}, 250);
	}

	function selectProduct(id, name, price) {
		$('#som-create-product-id').val(id);
		$('#som-create-product-search').val(name);
		$('#som-product-results').empty().hide();
		$('#som-create-selected').html('<strong>' + esc(name) + '</strong><span>' + price + '</span>').show();
	}

	function submitCreateOrder(e) {
		e.preventDefault();
		var productId = $('#som-create-product-id').val();
		if (!productId) {
			toast('Please select a product from the list.', 'error');
			return;
		}

		var $btn = $('#som-create-order-form').find('button[type="submit"]').prop('disabled', true).text('Creating...');
		$.post(somData.ajaxUrl, {
			action: 'som_create_order',
			nonce: somData.nonce,
			customer_name: $('#som-create-name').val(),
			phone: $('#som-create-phone').val(),
			address: $('#som-create-address').val(),
			product_id: productId,
			quantity: $('#som-create-quantity').val(),
			note: $('#som-create-note').val()
		}, function (res) {
			$btn.prop('disabled', false).text('Create & Confirm');
			if (!res.success) { toast(res.data.message || somData.i18n.error, 'error'); return; }
			closeCreateModal();
			loadCounts();
			loadMetrics();
			state.status = 'confirmed';
			state.page = 1;
			$('.som-tab').removeClass('is-active');
			$('.som-tab[data-status="confirmed"]').addClass('is-active');
			fetchOrders();
			toast(res.data.message + ' #' + res.data.order_number, 'success');
		}).fail(function () {
			$btn.prop('disabled', false).text('Create & Confirm');
			toast(somData.i18n.error, 'error');
		});
	}

	function openReportDrawer(name) {
		$('#som-report-drawer-title').text(name);
		$('#som-report-drawer-overlay').fadeIn(120);
		$('#som-report-drawer').addClass('is-open').attr('aria-hidden', 'false');
		loadReportActivity();
	}

	function closeReportDrawer() {
		$('#som-report-drawer').removeClass('is-open').attr('aria-hidden', 'true');
		$('#som-report-drawer-overlay').fadeOut(120);
	}

	function loadReportActivity() {
		var date = $('#som-report-activity-date').val();
		$('#som-report-activity-list').html('<div class="som-drawer-loading"><div class="som-spinner"></div><p>Loading history...</p></div>');
		$.post(somData.ajaxUrl, {
			action: 'som_get_staff_activity',
			nonce: somData.nonce,
			user_id: reportStaffId,
			date: date
		}, function (res) {
			if (!res.success || !res.data) {
				$('#som-report-activity-list').html('<p class="som-staff-empty">' + esc(somData.i18n.error) + '</p>');
				return;
			}
			renderReportActivity(res.data.items || []);
		}).fail(function () {
			$('#som-report-activity-list').html('<p class="som-staff-empty">' + esc(somData.i18n.error) + '</p>');
		});
	}

	function renderReportActivity(items) {
		if (!items.length) {
			$('#som-report-activity-list').html('<p class="som-staff-empty">No activity found for this date.</p>');
			return;
		}
		var html = items.map(function (item) {
			var order = item.order_id ? '<span>Order #' + esc(item.order_id) + '</span>' : '';
			return '<div class="som-report-activity-item">' +
				'<div><strong>' + esc(item.time || '') + '</strong>' + order + '</div>' +
				'<p>' + esc(item.message || '') + '</p>' +
			'</div>';
		}).join('');
		$('#som-report-activity-list').html(html);
	}

	function intelCard(label, value, rawHtml) {
		var shown = value !== undefined && value !== null && value !== '' ? value : '0';
		return '<div class="som-intel-card"><span>' + esc(label) + '</span><strong>' + (rawHtml ? shown : esc(shown)) + '</strong></div>';
	}

	function drawerSection(title, body) {
		return '<section class="som-drawer-section"><h3>' + esc(title) + '</h3>' + body + '</section>';
	}

	function infoRow(label, value) {
		return '<div class="som-info-row"><span>' + esc(label) + '</span><strong>' + value + '</strong></div>';
	}

	function renderItems(items) {
		if (!items.length) return '<p class="som-drawer-empty">No product items found.</p>';
		return items.map(function (item) {
			return '<div class="som-product-row"><div><strong>' + esc(item.name || '') + '</strong><span>Qty ' + esc(item.quantity || 0) + '</span></div><b>' + (item.total || '') + '</b></div>';
		}).join('');
	}

	function renderActivity(items) {
		if (!items.length) return '<p class="som-drawer-empty">No activity recorded for this order yet.</p>';
		return items.map(function (item) {
			return '<div class="som-drawer-activity"><span></span><div><p><strong>' + esc(item.user || 'System') + '</strong> ' + esc(item.message || '') + '</p><small>' + esc(item.time || '') + '</small></div></div>';
		}).join('');
	}

	// ── AJAX: fetch orders ─────────────────────────────────────────────────
	function fetchOrders() {
		if (state.loading) return;
		state.loading = true;
		$tbody.html('<tr><td colspan="8" class="som-loading-cell"><div class="som-spinner"></div><p>Loading orders…</p></td></tr>');

		$.post(somData.ajaxUrl, {
			action:    'som_get_orders',
			nonce:     somData.nonce,
			page:      state.page,
			search:    state.search,
			status:    state.status,
			range:     state.range,
			date_from: state.dateFrom,
			date_to:   state.dateTo,
			assigned_to: state.assignedTo,
		}, function (res) {
			state.loading = false;
			if (res.success) {
				state.page  = res.data.current_page;
				state.pages = res.data.pages;
				state.total = res.data.total;
				$tbody.html(res.data.html);
				$totalNum.text(res.data.total);
				if (res.data.today_count !== undefined) $todayNum.text(res.data.today_count);
				renderPagination();
				if (autoOpenOrderId) {
					openOrderDrawer(autoOpenOrderId);
					autoOpenOrderId = 0;
				}
			} else {
				$tbody.html('<tr class="som-no-results"><td colspan="8">' + esc(somData.i18n.error) + '</td></tr>');
			}
		}).fail(function () {
			state.loading = false;
			$tbody.html('<tr class="som-no-results"><td colspan="8">' + esc(somData.i18n.error) + '</td></tr>');
		});
	}

	// ── Pagination ─────────────────────────────────────────────────────────
	function renderPagination() {
		var p = state.page, pp = state.pages, t = state.total, per = somData.perPage;
		if (t === 0) { $pageInfo.text('No orders found.'); $pageBtns.html(''); return; }
		var s = (p - 1) * per + 1, e = Math.min(p * per, t);
		$pageInfo.text('Showing ' + s + '–' + e + ' of ' + t + ' orders');

		var h = mkBtn(p - 1, '‹', p <= 1);
		pageRange(p, pp).forEach(function (n, i, arr) {
			if (i > 0 && n - arr[i-1] > 1) h += '<button class="som-page-btn" disabled>…</button>';
			h += mkBtn(n, n, false, n === p);
		});
		h += mkBtn(p + 1, '›', p >= pp);
		$pageBtns.html(h);

		$pageBtns.find('.som-page-btn:not(:disabled)').on('click', function () {
			var pg = parseInt($(this).data('page'), 10);
			if (pg >= 1 && pg <= pp) { state.page = pg; fetchOrders(); }
		});
	}

	function mkBtn(page, label, disabled, active) {
		return '<button class="som-page-btn' + (active ? ' is-active' : '') + '" data-page="' + page + '"' + (disabled ? ' disabled' : '') + '>' + label + '</button>';
	}

	function pageRange(cur, total) {
		if (total <= 7) return range(1, total);
		var r = [1];
		for (var i = Math.max(2, cur-2); i <= Math.min(total-1, cur+2); i++) r.push(i);
		r.push(total);
		return r;
	}
	function range(a, b) { var r = []; for (var i = a; i <= b; i++) r.push(i); return r; }

	// ── Note helpers ────────────────────────────────────────────────────────
	function showEditor($r, val) {
		$r.find('.som-note-display, .som-btn-add-note').hide();
		$r.find('.som-note-editor').slideDown(140);
		$r.find('.som-note-input').val(val).focus();
	}
	function hideEditor($r) {
		var $d = $r.find('.som-note-display'), $a = $r.find('.som-btn-add-note');
		$r.find('.som-note-editor').slideUp(140, function () {
			$d.length && $d.find('.som-note-text').text().trim() ? $d.show() : $a.show();
		});
	}

	// ── AJAX: save note ─────────────────────────────────────────────────────
	function doSaveNote($r, id, note) {
		var $btn = $r.find('.som-btn-save-note').prop('disabled', true).text(somData.i18n.saving);
		$.post(somData.ajaxUrl, { action: 'som_save_note', nonce: somData.nonce, order_id: id, note: note }, function (res) {
			$btn.prop('disabled', false).text('Save');
			if (!res.success) { toast(res.data.message || somData.i18n.error, 'error'); return; }

			var $w = $r.find('.som-note-wrapper');
			var $d = $w.find('.som-note-display'), $a = $w.find('.som-btn-add-note');
			$r.find('.som-note-editor').slideUp(140);

			if (note.trim()) {
				if (!$d.length) { $a.replaceWith(noteDisplayHtml(note)); }
				else { $d.find('.som-note-text').text(note); $d.show(); }
			} else {
				$d.remove(); $a.show();
			}

			if (res.data.status) updateBadge($r, res.data.status, res.data.status_label);
			if (res.data.assigned_name) updateHandledBy($r, res.data.assigned_name);
			setCounts(res.data.counts);
			loadMetrics();

			// If viewing Pending tab and order moved to on-hold, remove row
			if (state.status === 'pending' && res.data.status === 'on-hold') {
				rowOut($r, function () { if (!$tbody.find('tr[data-order-id]').length) fetchOrders(); });
			}

			toast('✅ ' + somData.i18n.saved, 'success');
		}).fail(function () { $btn.prop('disabled', false).text('Save'); toast(somData.i18n.error, 'error'); });
	}

	// ── AJAX: delete note ────────────────────────────────────────────────────
	function doDeleteNote($r, id) {
		$r.addClass('som-row-loading');
		$.post(somData.ajaxUrl, { action: 'som_delete_note', nonce: somData.nonce, order_id: id }, function (res) {
			$r.removeClass('som-row-loading');
			closeModal();
			if (!res.success) { toast(res.data.message || somData.i18n.error, 'error'); return; }
			var $w = $r.find('.som-note-wrapper');
			$w.find('.som-note-display').remove();
			$w.find('.som-note-editor').hide();
			if (!$w.find('.som-btn-add-note').length) $w.append('<button class="som-btn-add-note">＋ Add Note</button>');
			else $w.find('.som-btn-add-note').show();
			setCounts(res.data.counts);
			toast('🗑 ' + somData.i18n.deleted, 'info');
		}).fail(function () { $r.removeClass('som-row-loading'); closeModal(); toast(somData.i18n.error, 'error'); });
	}

	// ── AJAX: single status ──────────────────────────────────────────────────
	function doUpdateStatus($r, id, action) {
		$r.addClass('som-row-loading');
		$.post(somData.ajaxUrl, { action: 'som_update_status', nonce: somData.nonce, order_id: id, status_action: action }, function (res) {
			$r.removeClass('som-row-loading');
			if (!res.success) { toast(res.data.message || somData.i18n.error, 'error'); return; }
			updateBadge($r, res.data.status, res.data.status_label);
			if (res.data.assigned_name) updateHandledBy($r, res.data.assigned_name);
			setCounts(res.data.counts);
			loadMetrics();
			if (state.status !== 'all' && res.data.status !== state.status) {
				rowOut($r, function () { if (!$tbody.find('tr[data-order-id]').length) fetchOrders(); });
			}
			toast('✅ ' + somData.i18n.statusUpdated, 'success');
			if ($drawer.hasClass('is-open')) openOrderDrawer(id);
		}).fail(function () { $r.removeClass('som-row-loading'); toast(somData.i18n.error, 'error'); });
	}

	// ── AJAX: bulk delete ────────────────────────────────────────────────────
	function doBulkDelete(ids) {
		$.post(somData.ajaxUrl, { action: 'som_bulk_delete', nonce: somData.nonce, order_ids: ids }, function (res) {
			closeModal();
			if (!res.success) { toast(res.data.message || somData.i18n.error, 'error'); return; }
			setCounts(res.data.counts);
			loadMetrics();
			clearBulk();
			state.page = 1;
			fetchOrders();
			toast('🗑 ' + res.data.message, 'success');
		}).fail(function () { closeModal(); toast(somData.i18n.error, 'error'); });
	}

	// ── AJAX: bulk status ────────────────────────────────────────────────────
	function doBulkStatus(ids, action) {
		$.post(somData.ajaxUrl, { action: 'som_bulk_status', nonce: somData.nonce, order_ids: ids, status_action: action }, function (res) {
			if (!res.success) { toast(res.data.message || somData.i18n.error, 'error'); return; }
			setCounts(res.data.counts);
			loadMetrics();
			clearBulk();
			state.page = 1;
			fetchOrders();
			toast('✅ ' + res.data.message, 'success');
		}).fail(function () { toast(somData.i18n.error, 'error'); });
	}

	// ── Bulk helpers ────────────────────────────────────────────────────────
	function getSelectedIds() {
		return $tbody.find('.som-row-check:checked').map(function () { return $(this).val(); }).get();
	}
	function syncBulkBar() {
		var n = getSelectedIds().length;
		$selCount.text(n);
		n > 0 ? $bulkBar.slideDown(130) : $bulkBar.slideUp(130);
	}
	function clearBulk() {
		$tbody.find('.som-row-check').prop('checked', false);
		$tbody.find('tr').removeClass('is-selected');
		$checkAll.prop('checked', false).prop('indeterminate', false);
		$('#som-bulk-action-select').val('');
		$bulkBar.slideUp(130);
	}

	// ── Modal ────────────────────────────────────────────────────────────────
	var _cb = null;
	function openModal(icon, title, body, cb) {
		_cb = cb;
		$('#som-modal-icon').text(icon);
		$('#som-modal-title').text(title);
		$('#som-modal-body').text(body);
		$overlay.fadeIn(160);
		$('#som-modal-confirm').off('click').on('click', function () { if (_cb) _cb(); });
	}
	function closeModal() { $overlay.fadeOut(140); _cb = null; }

	// ── Misc helpers ─────────────────────────────────────────────────────────
	function updateBadge($r, status, label) {
		$r.find('.som-status-badge').attr('class', 'som-status-badge som-status--' + status).text(label);
	}
	function updateHandledBy($r, name) {
		if (!$r || !$r.length || !name) return;
		$r.find('.som-assigned-pill').text('Handled by ' + name).attr('data-assigned-label', name);
	}
	function noteDisplayHtml(note) {
		return '<div class="som-note-display">' +
			'<p class="som-note-text">' + esc(note) + '</p>' +
			'<div class="som-note-actions">' +
			'<button class="som-btn-edit-note">✏️ Edit</button>' +
			'<button class="som-btn-delete-note">🗑 Delete</button>' +
			'</div></div>';
	}
	function rowOut($r, cb) {
		$r.css({ transition: 'opacity .28s, transform .28s', opacity: 0, transform: 'translateX(16px)' });
		setTimeout(function () { $r.remove(); if (cb) cb(); }, 300);
	}
	function closeDropdowns() {
		$('.som-action-menu.is-open').removeClass('is-open');
		$('.som-action-toggle[aria-expanded="true"]').attr('aria-expanded', 'false');
	}
	function esc(s) {
		return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
	}
	function escAttr(s) {
		return esc(s).replace(/'/g, '&#039;');
	}
	function toast(msg, type) {
		type = type || 'info';
		var $t = $('<div class="som-toast som-toast-' + type + '">' + esc(msg) + '</div>');
		$('#som-toast-container').append($t);
		setTimeout(function () { $t.addClass('som-toast-out'); setTimeout(function () { $t.remove(); }, 220); }, 3200);
	}

})(jQuery);
