<?php
/**
 * Plugin Name: OrderPilot Pro for WooCommerce
 * Plugin URI:  https://sukunaat.com
 * Description: A premium WooCommerce order management dashboard for faster, cleaner order processing.
 * Version:     1.3.2
 * Author:      Sukunaat
 * Author URI:  https://sukunaat.com
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: sukunaat-order-manager
 * Domain Path: /languages
 *
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.5
 *
 * @package SukunaatOrderManager
 */

defined( 'ABSPATH' ) || exit;

// Plugin constants.
define( 'SOM_VERSION',     '1.3.2' );
define( 'SOM_PLUGIN_FILE', __FILE__ );
define( 'SOM_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'SOM_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'SOM_PLUGIN_BASE', plugin_basename( __FILE__ ) );

/**
 * Check WooCommerce is active before loading anything.
 */
function som_check_woocommerce() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'som_woocommerce_missing_notice' );
		return false;
	}
	return true;
}

function som_woocommerce_missing_notice() {
	echo '<div class="notice notice-error"><p>'
		. esc_html__( 'OrderPilot Pro for WooCommerce requires WooCommerce to be installed and active.', 'sukunaat-order-manager' )
		. '</p></div>';
}

/**
 * Boot the plugin.
 */
function som_init() {
	if ( ! som_check_woocommerce() ) {
		return;
	}

	require_once SOM_PLUGIN_DIR . 'includes/class-loader.php';
	\SukunaatOrderManager\Loader::instance()->init();
}
add_action( 'plugins_loaded', 'som_init' );

function som_activate() {
	require_once SOM_PLUGIN_DIR . 'includes/class-activity-log.php';
	require_once SOM_PLUGIN_DIR . 'includes/class-staff-page.php';

	\SukunaatOrderManager\Activity_Log::install();
	\SukunaatOrderManager\Staff_Page::install_role();
	update_option( 'som_install_version', SOM_VERSION );
}
register_activation_hook( __FILE__, 'som_activate' );

/**
 * Declare HPOS compatibility.
 */
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );
