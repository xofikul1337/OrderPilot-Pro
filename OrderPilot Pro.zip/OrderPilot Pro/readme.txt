=== OrderPilot Pro for WooCommerce ===
Contributors: sukunaat
Tags: woocommerce, orders, order management, admin dashboard
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.3.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A premium WooCommerce order management dashboard — faster, cleaner order processing without touching the default WooCommerce order screen.

== Description ==

OrderPilot Pro for WooCommerce adds a dedicated, modern admin dashboard for managing WooCommerce orders. It reads directly from your WooCommerce order data with no duplicate order database.

**Features:**

* Clean, responsive order table — Name, Phone, Address, Product, Note, Status, Actions
* Inline note system (add / edit / delete) stored as WC order meta
* Auto status: pending → on-hold when a note is first saved
* Action dropdown: Confirm Order, On Hold, Sent To Courier, Cancel Order
* Custom "Sent To Courier" WooCommerce order status
* Color-coded status badges
* Instant AJAX search (name, phone, address)
* AJAX pagination — 10 orders per page, newest first
* Toast notifications, loading spinners, smooth transitions
* Automatic mobile store code and Worker registration
* Shared mobile order history and first-seen staff tracking
* Full WordPress security: nonce verification, capability checks, output escaping

**WooCommerce Compatibility:**

Works with both legacy post-based orders and HPOS (High-Performance Order Storage).

== Installation ==

1. Upload the `sukunaat-order-manager` folder to `/wp-content/plugins/`
2. Activate the plugin through the **Plugins** menu in WordPress
3. Look for **OrderPilot Pro** in the admin sidebar

== Frequently Asked Questions ==

= Does this create a separate order database? =
No. All data comes directly from WooCommerce orders.

= Is it compatible with CartFlows? =
Yes. Orders created via CartFlows are standard WooCommerce orders and will appear in the dashboard.

= What happens to notes if I uninstall the plugin? =
Notes are stored as WooCommerce order meta and are preserved unless you choose to remove them manually.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
