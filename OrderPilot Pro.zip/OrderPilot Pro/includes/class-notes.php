<?php
/**
 * Handles admin notes stored as WooCommerce order meta.
 *
 * @package SukunaatOrderManager
 */

namespace SukunaatOrderManager;

defined( 'ABSPATH' ) || exit;

final class Notes {

	const META_KEY = '_sukunaat_admin_note';

	// Statuses that should auto-move to on-hold when a note is saved.
	const AUTO_HOLD_STATUSES = [ 'pending', 'processing' ];

	private static ?self $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function get( int $order_id ): string {
		$order = wc_get_order( $order_id );
		return $order ? (string) $order->get_meta( self::META_KEY, true ) : '';
	}

	/**
	 * Save note and auto-move to on-hold if order is pending or processing.
	 */
	public function save( int $order_id, string $note ): bool {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return false;
		}

		$note = sanitize_textarea_field( $note );
		$order->update_meta_data( self::META_KEY, $note );
		$order->save();

		// Auto → on-hold for pending AND processing orders when note is added.
		if ( '' !== trim( $note ) && in_array( $order->get_status(), self::AUTO_HOLD_STATUSES, true ) ) {
			if ( ! defined( 'SOM_STATUS_CHANGE' ) ) {
				define( 'SOM_STATUS_CHANGE', true );
			}
			$order->update_status(
				'on-hold',
				__( 'Moved to On Hold automatically when admin note was added via OrderPilot Pro.', 'sukunaat-order-manager' )
			);
		}

		return true;
	}

	public function delete( int $order_id ): bool {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return false;
		}
		$order->delete_meta_data( self::META_KEY );
		$order->save();
		return true;
	}
}
