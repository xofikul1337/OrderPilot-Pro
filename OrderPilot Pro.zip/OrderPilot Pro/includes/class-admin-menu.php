<?php
/**
 * Registers the admin menu and enqueues plugin assets.
 *
 * @package SukunaatOrderManager
 */

namespace SukunaatOrderManager;

defined( 'ABSPATH' ) || exit;

final class Admin_Menu {

	private static ?self $instance = null;
	private string $hook_suffix = '';
	private string $reports_hook_suffix = '';
	private string $notifications_hook_suffix = '';

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function register(): void {
		add_action( 'admin_menu',            [ $this, 'add_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'admin_head',            [ $this, 'suppress_foreign_notices' ], 1 );
	}

	public function add_menu(): void {
		$this->hook_suffix = add_menu_page(
			__( 'OrderPilot Pro', 'sukunaat-order-manager' ),
			__( 'OrderPilot Pro', 'sukunaat-order-manager' ),
			'manage_som_orders',
			'sukunaat-order-manager',
			[ $this, 'render_page' ],
			'dashicons-list-view',
			56
		);

		$this->reports_hook_suffix = add_submenu_page(
			'sukunaat-order-manager',
			__( 'Reports & Staff Management', 'sukunaat-order-manager' ),
			__( 'Reports & Staff Management', 'sukunaat-order-manager' ),
			'manage_woocommerce',
			'sukunaat-order-manager-reports',
			[ $this, 'render_reports_page' ]
		);

		$this->notifications_hook_suffix = add_submenu_page(
			'sukunaat-order-manager',
			__( 'Notifications', 'sukunaat-order-manager' ),
			__( 'Notifications', 'sukunaat-order-manager' ),
			'manage_woocommerce',
			'sukunaat-order-manager-notifications',
			[ $this, 'render_notifications_page' ]
		);
	}

	public function enqueue_assets( string $hook ): void {
		if ( ! in_array( $hook, [ $this->hook_suffix, $this->reports_hook_suffix, $this->notifications_hook_suffix ], true ) ) {
			return;
		}

		wp_enqueue_style(
			'som-admin',
			SOM_PLUGIN_URL . 'assets/css/admin.css',
			[],
			(string) filemtime( SOM_PLUGIN_DIR . 'assets/css/admin.css' )
		);

		wp_enqueue_script(
			'som-admin',
			SOM_PLUGIN_URL . 'assets/js/admin.js',
			[ 'jquery' ],
			(string) filemtime( SOM_PLUGIN_DIR . 'assets/js/admin.js' ),
			true
		);

		wp_localize_script( 'som-admin', 'somData', [
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'som_nonce' ),
			'perPage' => Order_Table::PER_PAGE,
			'openOrderId' => isset( $_GET['som_open_order'] ) ? absint( $_GET['som_open_order'] ) : 0,
			'i18n'    => [
				'confirmDelete' => __( 'Are you sure you want to delete this note?', 'sukunaat-order-manager' ),
				'saving'        => __( 'Saving…', 'sukunaat-order-manager' ),
				'saved'         => __( 'Note saved!', 'sukunaat-order-manager' ),
				'deleted'       => __( 'Note deleted.', 'sukunaat-order-manager' ),
				'statusUpdated' => __( 'Status updated!', 'sukunaat-order-manager' ),
				'error'         => __( 'Something went wrong. Please try again.', 'sukunaat-order-manager' ),
			],
		] );
	}

	public function render_page(): void {
		if ( ! current_user_can( 'manage_som_orders' ) && ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'sukunaat-order-manager' ) );
		}
		include SOM_PLUGIN_DIR . 'templates/dashboard.php';
	}

	public function render_reports_page(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'sukunaat-order-manager' ) );
		}

		include SOM_PLUGIN_DIR . 'templates/reports.php';
	}

	public function render_notifications_page(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'sukunaat-order-manager' ) );
		}

		Notifications::instance()->maybe_handle_save();
		include SOM_PLUGIN_DIR . 'templates/notifications.php';
	}

	public function suppress_foreign_notices(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( $screen->id, [ $this->hook_suffix, $this->reports_hook_suffix, $this->notifications_hook_suffix ], true ) ) {
			return;
		}

		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
		remove_all_actions( 'network_admin_notices' );
		?>
		<style>
			body.toplevel_page_sukunaat-order-manager .notice,
			body.toplevel_page_sukunaat-order-manager .updated,
			body.toplevel_page_sukunaat-order-manager .error,
			body.sukunaat-orders_page_sukunaat-order-manager-reports .notice,
			body.sukunaat-orders_page_sukunaat-order-manager-reports .updated,
			body.sukunaat-orders_page_sukunaat-order-manager-reports .error {
				display: none !important;
			}
		</style>
		<?php
	}
}
