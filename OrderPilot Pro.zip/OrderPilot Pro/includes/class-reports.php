<?php
/**
 * Reporting helpers for order operations.
 *
 * @package SukunaatOrderManager
 */

namespace SukunaatOrderManager;

defined( 'ABSPATH' ) || exit;

final class Reports {

	private static ?self $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function summary( array $filters = [] ): array {
		$range = $filters['range'] ?? 'month';
		$from  = $filters['from'] ?? '';
		$to    = $filters['to'] ?? '';
		$search = $filters['search'] ?? '';

		$active_orders    = $this->orders_by_status( Order_Table::SALE_STATUSES, $range, $from, $to );
		$confirmed_orders = $this->orders_by_status( [ 'wc-confirmed' ], $range, $from, $to );
		$cancelled_orders = $this->orders_by_status( [ 'wc-cancelled' ], $range, $from, $to );
		$all_orders       = array_merge( $active_orders, $cancelled_orders );
		$sales_total      = $this->sum_totals( $active_orders );
		$cancel_rate      = count( $all_orders ) > 0 ? ( count( $cancelled_orders ) / count( $all_orders ) ) * 100 : 0;

		return [
			'cards' => [
				[
					'label' => __( 'Sales', 'sukunaat-order-manager' ),
					'value' => wc_price( $sales_total ),
					'note'  => sprintf( _n( '%d active order in range', '%d active orders in range', count( $active_orders ), 'sukunaat-order-manager' ), count( $active_orders ) ),
				],
				[
					'label' => __( 'Confirmed', 'sukunaat-order-manager' ),
					'value' => (string) count( $confirmed_orders ),
					'note'  => __( 'Confirmed in selected range', 'sukunaat-order-manager' ),
				],
				[
					'label' => __( 'Cancelled', 'sukunaat-order-manager' ),
					'value' => (string) count( $cancelled_orders ),
					'note'  => __( 'Cancelled in selected range', 'sukunaat-order-manager' ),
				],
				[
					'label' => __( 'Cancel Rate', 'sukunaat-order-manager' ),
					'value' => number_format_i18n( $cancel_rate, 1 ) . '%',
					'note'  => __( 'Cancelled vs active/cancelled', 'sukunaat-order-manager' ),
				],
			],
			'staff' => $this->staff_performance( $range, $from, $to, $search ),
		];
	}

	private function orders_by_status( array $statuses, string $range, string $from = '', string $to = '' ): array {
		return wc_get_orders(
			array_merge(
				[
					'limit'  => -1,
					'type'   => 'shop_order',
					'return' => 'objects',
					'status' => $statuses,
				],
				$this->date_args( $range, $from, $to )
			)
		);
	}

	private function date_args( string $range, string $from = '', string $to = '' ): array {
		$tz  = wp_timezone();
		$now = new \DateTime( 'now', $tz );

		if ( 'today' === $range ) {
			$start = ( clone $now )->setTime( 0, 0, 0 );
			$end   = ( clone $now )->setTime( 23, 59, 59 );
			return [ 'date_created' => $start->getTimestamp() . '...' . $end->getTimestamp() ];
		}

		if ( 'month' === $range ) {
			$start = ( clone $now )->modify( 'first day of this month' )->setTime( 0, 0, 0 );
			$end   = ( clone $now )->setTime( 23, 59, 59 );
			return [ 'date_created' => $start->getTimestamp() . '...' . $end->getTimestamp() ];
		}

		if ( 'custom' === $range ) {
			$start = $from ? \DateTime::createFromFormat( 'Y-m-d H:i:s', sanitize_text_field( $from ) . ' 00:00:00', $tz ) : null;
			$end   = $to ? \DateTime::createFromFormat( 'Y-m-d H:i:s', sanitize_text_field( $to ) . ' 23:59:59', $tz ) : null;
			if ( $start && $end ) {
				return [ 'date_created' => $start->getTimestamp() . '...' . $end->getTimestamp() ];
			}
			if ( $start ) {
				return [ 'date_created' => '>' . $start->getTimestamp() ];
			}
			if ( $end ) {
				return [ 'date_created' => '<' . $end->getTimestamp() ];
			}
		}

		return [];
	}

	private function log_date_where( string $range, string $from = '', string $to = '' ): array {
		$tz  = wp_timezone();
		$now = new \DateTime( 'now', $tz );

		if ( 'today' === $range ) {
			$start = ( clone $now )->setTime( 0, 0, 0 );
			$end   = ( clone $now )->setTime( 23, 59, 59 );
			return [ $start->format( 'Y-m-d H:i:s' ), $end->format( 'Y-m-d H:i:s' ) ];
		}

		if ( 'month' === $range ) {
			$start = ( clone $now )->modify( 'first day of this month' )->setTime( 0, 0, 0 );
			$end   = ( clone $now )->setTime( 23, 59, 59 );
			return [ $start->format( 'Y-m-d H:i:s' ), $end->format( 'Y-m-d H:i:s' ) ];
		}

		if ( 'custom' === $range ) {
			$start = $from ? sanitize_text_field( $from ) . ' 00:00:00' : '1970-01-01 00:00:00';
			$end   = $to ? sanitize_text_field( $to ) . ' 23:59:59' : '2999-12-31 23:59:59';
			return [ $start, $end ];
		}

		return [ '1970-01-01 00:00:00', '2999-12-31 23:59:59' ];
	}

	private function sum_totals( array $orders ): float {
		$total = 0.0;
		foreach ( $orders as $order ) {
			if ( $order instanceof \WC_Order ) {
				$total += (float) $order->get_total();
			}
		}
		return $total;
	}

	private function staff_performance( string $range, string $from, string $to, string $search ): array {
		global $wpdb;

		$table = Activity_Log::table_name();
		[ $start, $end ] = $this->log_date_where( $range, $from, $to );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table}
				WHERE user_id > 0
				AND action IN ('status_updated','bulk_status_updated','manual_order_created')
				AND created_at BETWEEN %s AND %s
				ORDER BY created_at DESC, id DESC",
				$start,
				$end
			),
			ARRAY_A
		);

		$staff = [];
		foreach ( is_array( $rows ) ? $rows : [] as $row ) {
			$context = ! empty( $row['context'] ) ? json_decode( $row['context'], true ) : [];
			$is_confirm = 'manual_order_created' === $row['action'] || (
				is_array( $context )
				&& isset( $context['to'] )
				&& 'confirmed' === $context['to']
				&& ( ! isset( $context['from'] ) || 'confirmed' !== $context['from'] )
			);
			if ( ! $is_confirm ) {
				continue;
			}

			$user = get_userdata( (int) $row['user_id'] );
			if ( ! $user ) {
				continue;
			}

			if ( '' !== $search ) {
				$haystack = strtolower( $user->display_name . ' ' . $user->user_email );
				if ( false === strpos( $haystack, strtolower( $search ) ) ) {
					continue;
				}
			}

			$user_id = (int) $row['user_id'];
			if ( ! isset( $staff[ $user_id ] ) ) {
				$staff[ $user_id ] = [
					'id'        => $user_id,
					'name'      => $user->display_name,
					'email'     => $user->user_email,
					'confirmed' => 0,
					'details'   => [],
				];
			}

			$staff[ $user_id ]['confirmed']++;
			$staff[ $user_id ]['details'][] = [
				'order_id' => (int) $row['order_id'],
				'time'     => mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $row['created_at'] ),
				'message'  => $row['message'],
			];
		}

		usort( $staff, function ( $a, $b ) {
			return $b['confirmed'] <=> $a['confirmed'];
		} );

		return $staff;
	}
}
