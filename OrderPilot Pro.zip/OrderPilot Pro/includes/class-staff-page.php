<?php
/**
 * Staff account and activity page.
 *
 * @package SukunaatOrderManager
 */

namespace SukunaatOrderManager;

defined( 'ABSPATH' ) || exit;

final class Staff_Page {

	const ROLE = 'som_order_agent';

	private static ?self $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public static function install_role(): void {
		add_role(
			self::ROLE,
			__( 'Sukunaat Order Agent', 'sukunaat-order-manager' ),
			[
				'read'              => true,
				'manage_som_orders' => true,
			]
		);

		$agent_role = get_role( self::ROLE );
		if ( $agent_role && ! $agent_role->has_cap( 'manage_som_orders' ) ) {
			$agent_role->add_cap( 'manage_som_orders' );
		}

		foreach ( [ 'administrator', 'shop_manager' ] as $role_name ) {
			$role = get_role( $role_name );
			if ( $role && ! $role->has_cap( 'manage_som_orders' ) ) {
				$role->add_cap( 'manage_som_orders' );
			}
		}
	}

	public function maybe_handle_create(): void {
		if ( ! isset( $_POST['som_create_staff'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'sukunaat-order-manager' ) );
		}

		check_admin_referer( 'som_create_staff', 'som_staff_nonce' );

		$name     = isset( $_POST['som_staff_name'] ) ? sanitize_text_field( wp_unslash( $_POST['som_staff_name'] ) ) : '';
		$email    = isset( $_POST['som_staff_email'] ) ? sanitize_email( wp_unslash( $_POST['som_staff_email'] ) ) : '';
		$password = isset( $_POST['som_staff_password'] ) ? (string) wp_unslash( $_POST['som_staff_password'] ) : '';

		if ( '' === $name || ! is_email( $email ) || strlen( $password ) < 8 ) {
			add_settings_error(
				'som_staff',
				'som_staff_invalid',
				__( 'Please enter a name, valid email, and password with at least 8 characters.', 'sukunaat-order-manager' ),
				'error'
			);
			return;
		}

		if ( email_exists( $email ) ) {
			add_settings_error(
				'som_staff',
				'som_staff_exists',
				__( 'A user with this email already exists.', 'sukunaat-order-manager' ),
				'error'
			);
			return;
		}

		$user_id = wp_create_user( $email, $password, $email );
		if ( is_wp_error( $user_id ) ) {
			add_settings_error( 'som_staff', 'som_staff_failed', $user_id->get_error_message(), 'error' );
			return;
		}

		wp_update_user(
			[
				'ID'           => $user_id,
				'display_name' => $name,
				'first_name'   => $name,
				'role'         => self::ROLE,
			]
		);

		Activity_Log::instance()->record(
			'staff_created',
			sprintf( __( 'Created staff account for %s.', 'sukunaat-order-manager' ), $name ),
			0,
			[ 'staff_user_id' => $user_id ]
		);

		add_settings_error(
			'som_staff',
			'som_staff_created',
			__( 'Staff account created successfully.', 'sukunaat-order-manager' ),
			'success'
		);
	}

	public function get_staff_users(): array {
		return get_users(
			[
				'role'    => self::ROLE,
				'orderby' => 'registered',
				'order'   => 'DESC',
				'fields'  => [ 'ID', 'display_name', 'user_email', 'user_registered' ],
			]
		);
	}

	public function get_staff_options(): array {
		$options = [];
		foreach ( $this->get_staff_users() as $staff ) {
			$options[] = [
				'id'    => (int) $staff->ID,
				'name'  => $staff->display_name ?: $staff->user_email,
				'email' => $staff->user_email,
			];
		}
		return $options;
	}
}
