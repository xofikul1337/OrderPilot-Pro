<?php
/**
 * Fetches and prepares WooCommerce orders for display.
 *
 * KEY DESIGN DECISION:
 * - "Pending" tab shows: wc-pending + wc-processing (new orders land here)
 * - "Confirmed" tab shows: wc-confirmed (custom status set only by admin action)
 * - Admin clicking "Confirm Order" moves order → wc-confirmed (NOT wc-processing)
 *
 * @package SukunaatOrderManager
 */

namespace SukunaatOrderManager;

defined( 'ABSPATH' ) || exit;

final class Order_Table {

	const PER_PAGE       = 10;
	const ALLOWED_RANGES = [ 'all', 'today', 'yesterday', 'week', 'month', 'custom' ];

	// Statuses treated as "pending" in our UI (new/unreviewed orders)
	const PENDING_STATUSES = [ 'wc-pending', 'wc-processing' ];

	// All statuses shown in "All Orders" tab
	const ALL_STATUSES = [
		'wc-pending',
		'wc-processing',
		'wc-on-hold',
		'wc-sent-to-courier',
		'wc-confirmed',
		'wc-cancelled',
	];

	const SALE_STATUSES = [
		'wc-processing',
		'wc-on-hold',
		'wc-sent-to-courier',
		'wc-confirmed',
		'wc-completed',
	];

	private static ?self $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	// ── Date args ────────────────────────────────────────────────────────

	private function build_date_args( string $range, string $from = '', string $to = '' ): array {
		$tz  = wp_timezone();
		$now = new \DateTime( 'now', $tz );

		switch ( $range ) {
			case 'today':
				$start = ( clone $now )->setTime( 0, 0, 0 );
				$end   = ( clone $now )->setTime( 23, 59, 59 );
				return [ 'date_created' => $start->getTimestamp() . '...' . $end->getTimestamp() ];

			case 'yesterday':
				$start = ( clone $now )->modify( '-1 day' )->setTime( 0, 0, 0 );
				$end   = ( clone $now )->modify( '-1 day' )->setTime( 23, 59, 59 );
				return [ 'date_created' => $start->getTimestamp() . '...' . $end->getTimestamp() ];

			case 'week':
				$start = ( clone $now )->modify( 'monday this week' )->setTime( 0, 0, 0 );
				$end   = ( clone $now )->setTime( 23, 59, 59 );
				return [ 'date_created' => $start->getTimestamp() . '...' . $end->getTimestamp() ];

			case 'month':
				$start = ( clone $now )->modify( 'first day of this month' )->setTime( 0, 0, 0 );
				$end   = ( clone $now )->setTime( 23, 59, 59 );
				return [ 'date_created' => $start->getTimestamp() . '...' . $end->getTimestamp() ];

			case 'custom':
				$start = $from ? \DateTime::createFromFormat( 'Y-m-d H:i:s', sanitize_text_field( $from ) . ' 00:00:00', $tz ) : null;
				$end   = $to ? \DateTime::createFromFormat( 'Y-m-d H:i:s', sanitize_text_field( $to ) . ' 23:59:59', $tz ) : null;
				if ( $start && $end ) {
					return [ 'date_created' => $start->getTimestamp() . '...' . $end->getTimestamp() ];
				}
				if ( $start ) {
					return [ 'date_created' => '>' . $start->getTimestamp() ];
				}
				if ( $end ) {
					return [ 'date_created' => '<' . $end->getTimestamp() ];
				}
				return [];

			default:
				return [];
		}
	}

	// ── Status args per tab slug ──────────────────────────────────────────

	/**
	 * Convert tab slug → wc_get_orders 'status' argument.
	 * Pending tab returns BOTH pending and processing.
	 */
	private function status_args( string $tab ): array {
		switch ( $tab ) {
			case 'pending':
				// Show new unreviewed orders: WC pending + WC processing
				return [ 'status' => self::PENDING_STATUSES ];

			case 'on-hold':
				return [ 'status' => [ 'wc-on-hold' ] ];

			case 'sent-to-courier':
				return [ 'status' => [ 'wc-sent-to-courier' ] ];

			case 'confirmed':
				// Only orders explicitly confirmed by admin via our plugin
				return [ 'status' => [ 'wc-confirmed' ] ];

			case 'cancelled':
				return [ 'status' => [ 'wc-cancelled' ] ];

			default: // 'all'
				return [ 'status' => self::ALL_STATUSES ];
		}
	}

	// ── Today count ───────────────────────────────────────────────────────

	public function get_today_count(): int {
		$args = array_merge(
			[ 'limit' => -1, 'return' => 'ids', 'type' => 'shop_order', 'status' => self::ALL_STATUSES ],
			$this->build_date_args( 'today' )
		);
		return count( wc_get_orders( $args ) );
	}

	public function get_dashboard_metrics(): array {
		$today_args = $this->build_date_args( 'today' );
		$month_args = $this->build_date_args( 'month' );

		$today_orders = $this->query_orders_for_metrics( self::SALE_STATUSES, $today_args );
		$month_orders = $this->query_orders_for_metrics( self::SALE_STATUSES, $month_args );
		$pending_orders = $this->query_orders_for_metrics( self::PENDING_STATUSES, [] );
		$cancelled_today = $this->get_cancelled_today_count();
		$cancelled_total = count( wc_get_orders( [ 'status' => 'wc-cancelled', 'limit' => -1, 'return' => 'ids', 'type' => 'shop_order' ] ) );

		$today_sales = $this->sum_order_totals( $today_orders );
		$month_sales = $this->sum_order_totals( $month_orders );
		$pending_amount = $this->sum_order_totals( $pending_orders );
		$avg_order = count( $today_orders ) > 0 ? $today_sales / count( $today_orders ) : 0;

		$chart = $this->get_sales_chart_data( 7 );
		$chart_total = array_sum( wp_list_pluck( $chart, 'amount' ) );

		return [
			'cards' => [
				'today_sales' => [
					'label'     => __( 'Today Sales', 'sukunaat-order-manager' ),
					'value'     => wc_price( $today_sales ),
					'raw'       => $today_sales,
					'sub_label' => sprintf(
						_n( '%d paid/active order', '%d paid/active orders', count( $today_orders ), 'sukunaat-order-manager' ),
						count( $today_orders )
					),
				],
				'month_sales' => [
					'label'     => __( 'This Month', 'sukunaat-order-manager' ),
					'value'     => wc_price( $month_sales ),
					'raw'       => $month_sales,
					'sub_label' => sprintf(
						_n( '%d active order', '%d active orders', count( $month_orders ), 'sukunaat-order-manager' ),
						count( $month_orders )
					),
				],
				'pending_amount' => [
					'label'     => __( 'Pending Amount', 'sukunaat-order-manager' ),
					'value'     => wc_price( $pending_amount ),
					'raw'       => $pending_amount,
					'sub_label' => sprintf(
						_n( '%d order needs review', '%d orders need review', count( $pending_orders ), 'sukunaat-order-manager' ),
						count( $pending_orders )
					),
				],
				'avg_order' => [
					'label'     => __( 'Avg Order Today', 'sukunaat-order-manager' ),
					'value'     => wc_price( $avg_order ),
					'raw'       => $avg_order,
					'sub_label' => sprintf(
						__( '%1$d cancellations today / %2$d total', 'sukunaat-order-manager' ),
						$cancelled_today,
						$cancelled_total
					),
				],
			],
			'chart' => $chart,
			'chart_total' => wc_price( $chart_total ),
		];
	}

	private function query_orders_for_metrics( array $statuses, array $date_args ): array {
		return wc_get_orders( array_merge(
			[
				'limit'   => -1,
				'return'  => 'objects',
				'type'    => 'shop_order',
				'status'  => $statuses,
				'orderby' => 'date',
				'order'   => 'ASC',
			],
			$date_args
		) );
	}

	private function get_cancelled_today_count(): int {
		$tz    = wp_timezone();
		$now   = new \DateTime( 'now', $tz );
		$start = ( clone $now )->setTime( 0, 0, 0 );
		$end   = ( clone $now )->setTime( 23, 59, 59 );

		$orders = wc_get_orders(
			[
				'limit'         => -1,
				'return'        => 'ids',
				'type'          => 'shop_order',
				'status'        => [ 'wc-cancelled' ],
				'date_modified' => $start->getTimestamp() . '...' . $end->getTimestamp(),
			]
		);

		return count( $orders );
	}

	private function sum_order_totals( array $orders ): float {
		$total = 0.0;
		foreach ( $orders as $order ) {
			if ( $order instanceof \WC_Order ) {
				$total += (float) $order->get_total();
			}
		}
		return $total;
	}

	private function get_sales_chart_data( int $days ): array {
		$tz = wp_timezone();
		$items = [];

		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$date = ( new \DateTime( 'now', $tz ) )->modify( '-' . $i . ' days' );
			$start = ( clone $date )->setTime( 0, 0, 0 );
			$end   = ( clone $date )->setTime( 23, 59, 59 );
			$args  = [ 'date_created' => $start->getTimestamp() . '...' . $end->getTimestamp() ];
			$orders = $this->query_orders_for_metrics( self::SALE_STATUSES, $args );
			$amount = $this->sum_order_totals( $orders );

			$items[] = [
				'label'           => $date->format( 'M j' ),
				'amount'          => $amount,
				'amount_formatted' => html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, get_bloginfo( 'charset' ) ),
				'orders'          => count( $orders ),
			];
		}

		return $items;
	}

	// ── Main query ────────────────────────────────────────────────────────

	public function get_orders(
		int    $page      = 1,
		string $search    = '',
		string $tab       = 'all',
		string $range     = 'all',
		string $date_from = '',
		string $date_to   = '',
		int    $assigned_to = -1
	): array {
		$page   = max( 1, $page );
		$search = sanitize_text_field( $search );
		$tab    = sanitize_key( $tab );
		$range  = sanitize_key( $range );
		$offset = ( $page - 1 ) * self::PER_PAGE;

		if ( ! in_array( $range, self::ALLOWED_RANGES, true ) ) {
			$range = 'all';
		}

		$base = array_merge(
			[
				'limit'   => self::PER_PAGE,
				'offset'  => $offset,
				'orderby' => 'date',
				'order'   => 'DESC',
				'return'  => 'objects',
				'type'    => 'shop_order',
			],
			$this->status_args( $tab )
		);

		// Search
		if ( '' !== $search ) {
			if ( is_numeric( $search ) ) {
				$base['post__in'] = [ (int) $search ];
			} else {
				$base['s'] = $search;
			}
		}

		$args       = array_merge( $base, $this->build_date_args( $range, $date_from, $date_to ) );
		if ( $assigned_to >= 0 ) {
			$args['meta_query'] = $this->assigned_meta_query( $assigned_to );
		}
		$orders     = wc_get_orders( $args );
		$count_args = array_merge( $args, [ 'limit' => -1, 'offset' => 0, 'return' => 'ids' ] );
		$total      = count( wc_get_orders( $count_args ) );

		// Supplemental phone/address search
		if ( '' !== $search && ! is_numeric( $search ) && $total < 1 ) {
			$orders = $this->meta_search( $search, $offset, $tab, $this->build_date_args( $range, $date_from, $date_to ), false, $assigned_to );
			$total  = count( $this->meta_search( $search, 0, $tab, $this->build_date_args( $range, $date_from, $date_to ), true, $assigned_to ) );
		}

		return [
			'orders' => $orders,
			'total'  => $total,
			'pages'  => max( 1, (int) ceil( $total / self::PER_PAGE ) ),
		];
	}

	// ── Status counts for tab badges ──────────────────────────────────────

	public function get_status_counts(): array {
		// Pending tab = pending + processing combined
		$pending_n = count( wc_get_orders( [ 'status' => self::PENDING_STATUSES, 'limit' => -1, 'return' => 'ids', 'type' => 'shop_order' ] ) );
		$onhold_n  = count( wc_get_orders( [ 'status' => 'wc-on-hold',          'limit' => -1, 'return' => 'ids', 'type' => 'shop_order' ] ) );
		$courier_n = count( wc_get_orders( [ 'status' => 'wc-sent-to-courier',  'limit' => -1, 'return' => 'ids', 'type' => 'shop_order' ] ) );
		$confirm_n = count( wc_get_orders( [ 'status' => 'wc-confirmed',        'limit' => -1, 'return' => 'ids', 'type' => 'shop_order' ] ) );
		$cancel_n  = count( wc_get_orders( [ 'status' => 'wc-cancelled',        'limit' => -1, 'return' => 'ids', 'type' => 'shop_order' ] ) );

		return [
			'all'              => $pending_n + $onhold_n + $courier_n + $confirm_n + $cancel_n,
			'pending'          => $pending_n,
			'on-hold'          => $onhold_n,
			'sent-to-courier'  => $courier_n,
			'confirmed'        => $confirm_n,
			'cancelled'        => $cancel_n,
		];
	}

	// ── Meta search ────────────────────────────────────────────────────────

	private function meta_search(
		string $search,
		int    $offset    = 0,
		string $tab       = 'all',
		array  $date_args = [],
		bool   $ids_only  = false,
		int    $assigned_to = -1
	): array {
		$meta_query = [
			'relation' => 'OR',
			[ 'key' => '_billing_phone',     'value' => $search, 'compare' => 'LIKE' ],
			[ 'key' => '_billing_address_1', 'value' => $search, 'compare' => 'LIKE' ],
			[ 'key' => '_billing_city',      'value' => $search, 'compare' => 'LIKE' ],
		];

		if ( $assigned_to >= 0 ) {
			$meta_query = [
				'relation' => 'AND',
				$meta_query,
				$this->assigned_meta_query( $assigned_to ),
			];
		}

		$args = array_merge(
			[
				'limit'      => $ids_only ? -1 : self::PER_PAGE,
				'offset'     => $ids_only ? 0 : $offset,
				'orderby'    => 'date',
				'order'      => 'DESC',
				'return'     => $ids_only ? 'ids' : 'objects',
				'type'       => 'shop_order',
				'meta_query' => $meta_query,
			],
			$this->status_args( $tab ),
			$date_args
		);
		return wc_get_orders( $args );
	}

	private function assigned_meta_query( int $assigned_to ): array {
		if ( 0 === $assigned_to ) {
			return [
				'relation' => 'OR',
				[ 'key' => '_som_assigned_to', 'compare' => 'NOT EXISTS' ],
				[ 'key' => '_som_assigned_to', 'value' => '', 'compare' => '=' ],
				[ 'key' => '_som_assigned_to', 'value' => '0', 'compare' => '=' ],
			];
		}

		return [
			[
				'key'     => '_som_assigned_to',
				'value'   => $assigned_to,
				'compare' => '=',
			],
		];
	}

	// ── Bulk delete ────────────────────────────────────────────────────────

	public function bulk_delete( array $ids ): int {
		$deleted = 0;
		foreach ( $ids as $id ) {
			$order = wc_get_order( (int) $id );
			if ( $order ) { $order->delete( true ); $deleted++; }
		}
		return $deleted;
	}

	// ── Format single order ────────────────────────────────────────────────

	public function format_order( \WC_Order $order ): array {
		$products = [];
		foreach ( $order->get_items() as $item ) {
			$products[] = $item->get_name();
		}

		$addr = array_filter( [
			$order->get_billing_address_1(),
			$order->get_billing_address_2(),
			$order->get_billing_city(),
		] );

		return [
			'id'           => $order->get_id(),
			'name'         => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'phone'        => $order->get_billing_phone(),
			'address'      => implode( ', ', $addr ),
			'products'     => implode( ', ', $products ),
			'note'         => (string) $order->get_meta( Notes::META_KEY, true ),
			'assigned_to'  => (int) $order->get_meta( '_som_assigned_to', true ),
			'assigned_name' => $this->get_assigned_name( (int) $order->get_meta( '_som_assigned_to', true ) ),
			'status'       => $order->get_status(),
			'status_label' => wc_get_order_status_name( $order->get_status() ),
			'date'         => $order->get_date_created() ? $order->get_date_created()->date_i18n( get_option( 'date_format' ) ) : '',
			'order_number' => $order->get_order_number(),
		];
	}

	private function get_assigned_name( int $user_id ): string {
		if ( $user_id < 1 ) {
			return '';
		}
		$user = get_userdata( $user_id );
		return $user ? $user->display_name : '';
	}
}
