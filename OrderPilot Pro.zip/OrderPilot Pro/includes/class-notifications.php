<?php
/**
 * Push notifications and mobile store registration.
 *
 * @package SukunaatOrderManager
 */

namespace SukunaatOrderManager;

defined( 'ABSPATH' ) || exit;

final class Notifications {

	const OPTION_ENABLED         = 'som_notifications_enabled';
	const OPTION_STORE_CODE      = 'som_store_code';
	const OPTION_SITE_SECRET     = 'som_site_secret';
	const OPTION_REGISTERED_CODE = 'som_registered_store_code';
	const OPTION_REGISTERED_STORAGE = 'som_registered_storage_version';
	const REGISTERED_STORAGE_VERSION = 'd1-v1';
	const WORKER_URL             = 'https://som-license.xofikul.workers.dev/notify';
	const WORKER_REGISTER_URL    = 'https://som-license.xofikul.workers.dev/register-store';
	const NOTIFY_SECRET          = 'SOM_NOTIFY_2024';

	private static ?self $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	/**
	 * Create everything a store needs automatically on activation/update.
	 */
	public static function install(): void {
		add_option( self::OPTION_ENABLED, 'yes' );

		$code = (string) get_option( self::OPTION_STORE_CODE, '' );
		if ( ! preg_match( '/^\d{6}$/', $code ) ) {
			update_option( self::OPTION_STORE_CODE, (string) wp_rand( 100000, 999999 ) );
		}

		if ( '' === (string) get_option( self::OPTION_SITE_SECRET, '' ) ) {
			update_option( self::OPTION_SITE_SECRET, wp_generate_password( 48, false, false ) );
		}
	}

	public function register(): void {
		self::install();

		add_action( 'woocommerce_new_order', [ $this, 'send_new_order_notification' ], 20, 2 );
		add_action( 'woocommerce_thankyou', [ $this, 'handle_thankyou' ], 20, 1 );
		add_action( 'woocommerce_payment_complete', [ $this, 'handle_payment_complete' ], 20, 1 );
		add_action( 'woocommerce_checkout_order_created', [ $this, 'handle_order_created' ], 20, 1 );
		add_action( 'wp_ajax_som_toggle_notifications', [ $this, 'ajax_toggle' ] );
		add_action( 'wp_ajax_som_save_store_code', [ $this, 'ajax_save_store_code' ] );
		add_action( 'admin_init', [ $this, 'maybe_register_store' ] );
		add_action( 'som_retry_order_notification', [ $this, 'retry_order_notification' ], 10, 2 );
	}

	private function already_notified( int $order_id ): bool {
		$order = wc_get_order( $order_id );
		return $order ? (bool) $order->get_meta( '_som_notified', true ) : false;
	}

	private function mark_notified( int $order_id ): void {
		$order = wc_get_order( $order_id );
		if ( $order ) {
			$order->update_meta_data( '_som_notified', '1' );
			$order->save();
		}
	}

	private function acquire_notification_lock( int $order_id ): bool {
		$key = 'som_notify_lock_' . $order_id;
		if ( add_option( $key, (string) time(), '', false ) ) {
			return true;
		}

		$locked_at = (int) get_option( $key, 0 );
		if ( $locked_at > 0 && $locked_at < time() - 120 ) {
			delete_option( $key );
			return add_option( $key, (string) time(), '', false );
		}

		return false;
	}

	private function release_notification_lock( int $order_id ): void {
		delete_option( 'som_notify_lock_' . $order_id );
	}

	public function handle_thankyou( int $order_id ): void {
		if ( ! $this->already_notified( $order_id ) ) {
			$this->send_new_order_notification( $order_id );
		}
	}

	public function handle_payment_complete( int $order_id ): void {
		if ( ! $this->already_notified( $order_id ) ) {
			$this->send_new_order_notification( $order_id );
		}
	}

	public function handle_order_created( $order ): void {
		$order_id = is_object( $order ) ? $order->get_id() : (int) $order;
		if ( ! $this->already_notified( $order_id ) ) {
			$this->send_new_order_notification( $order_id );
		}
	}

	public function get_store_code(): string {
		return (string) get_option( self::OPTION_STORE_CODE, '' );
	}

	private function get_site_secret(): string {
		return (string) get_option( self::OPTION_SITE_SECRET, '' );
	}

	public function is_enabled(): bool {
		return get_option( self::OPTION_ENABLED, 'no' ) === 'yes';
	}

	public function ajax_toggle(): void {
		check_ajax_referer( 'som_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [], 403 );
		}
		$enabled = ( isset( $_POST['enabled'] ) && 'true' === $_POST['enabled'] ) ? 'yes' : 'no';
		update_option( self::OPTION_ENABLED, $enabled );
		wp_send_json_success( [ 'enabled' => $enabled === 'yes' ] );
	}

	public function ajax_save_store_code(): void {
		check_ajax_referer( 'som_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [], 403 );
		}

		$code = isset( $_POST['code'] ) ? preg_replace( '/[^0-9]/', '', wp_unslash( $_POST['code'] ) ) : '';
		$code = substr( $code, 0, 6 );
		if ( strlen( $code ) !== 6 ) {
			wp_send_json_error( [ 'message' => 'Store code must be exactly 6 digits.' ] );
		}

		update_option( self::OPTION_STORE_CODE, $code );
		delete_option( self::OPTION_REGISTERED_CODE );
		$this->register_store();
		wp_send_json_success( [ 'code' => $code ] );
	}

	public function maybe_handle_save(): void {
		// Handled via AJAX.
	}

	public function maybe_register_store(): void {
		$code = $this->get_store_code();
		if (
			$code
			&& (
				get_option( self::OPTION_REGISTERED_CODE, '' ) !== $code
				|| get_option( self::OPTION_REGISTERED_STORAGE, '' ) !== self::REGISTERED_STORAGE_VERSION
			)
		) {
			$this->register_store();
		}
	}

	private function register_store(): bool {
		$code = $this->get_store_code();
		if ( ! preg_match( '/^\d{6}$/', $code ) ) {
			return false;
		}

		$response = wp_remote_post(
			self::WORKER_REGISTER_URL,
			[
				'timeout' => 15,
				'headers' => [ 'Content-Type' => 'application/json' ],
				'body'    => wp_json_encode(
					[
						'secret'      => self::NOTIFY_SECRET,
						'store_code'  => $code,
						'site_secret' => $this->get_site_secret(),
						'site_url'    => home_url( '/' ),
						'site_name'   => get_bloginfo( 'name' ),
					]
				),
			]
		);

		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) >= 300 ) {
			return false;
		}

		update_option( self::OPTION_REGISTERED_CODE, $code );
		update_option( self::OPTION_REGISTERED_STORAGE, self::REGISTERED_STORAGE_VERSION );
		return true;
	}

	public function retry_order_notification( int $order_id, int $attempt = 1 ): void {
		if ( ! $this->already_notified( $order_id ) ) {
			$this->send_new_order_notification( $order_id, null, $attempt );
		}
	}

	private function schedule_retry( int $order_id, int $attempt ): void {
		if ( $attempt >= 5 ) {
			return;
		}

		$next_attempt = $attempt + 1;
		$run_at       = time() + min( 300 * ( 2 ** $attempt ), 3600 );
		$args         = [ $order_id, $next_attempt ];

		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_schedule_single_action' ) ) {
			if ( ! as_has_scheduled_action( 'som_retry_order_notification', $args, 'orderpilot' ) ) {
				as_schedule_single_action( $run_at, 'som_retry_order_notification', $args, 'orderpilot' );
			}
			return;
		}

		if ( ! wp_next_scheduled( 'som_retry_order_notification', $args ) ) {
			wp_schedule_single_event( $run_at, 'som_retry_order_notification', $args );
		}
	}

	public function send_new_order_notification( int $order_id, $order = null, int $attempt = 0 ): void {
		if ( ! $this->is_enabled() ) {
			return;
		}

		$code = $this->get_store_code();
		if ( ! preg_match( '/^\d{6}$/', $code ) ) {
			return;
		}

		$order = $order instanceof \WC_Order ? $order : wc_get_order( $order_id );
		if ( ! $order || $this->already_notified( $order_id ) ) {
			return;
		}

		if ( ! $this->acquire_notification_lock( $order_id ) ) {
			return;
		}

		if ( $this->already_notified( $order_id ) ) {
			$this->release_notification_lock( $order_id );
			return;
		}

		$name    = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		$phone   = $order->get_billing_phone();
		$title   = 'New Order #' . $order->get_order_number();
		$message = $name ? $name . ( $phone ? ' - ' . $phone : '' ) : 'A new order arrived.';
		$url     = admin_url( 'post.php?post=' . $order->get_id() . '&action=edit' );

		$this->register_store();

		$response = wp_remote_post(
			self::WORKER_URL,
			[
				'timeout' => 15,
				'headers' => [ 'Content-Type' => 'application/json' ],
				'body'    => wp_json_encode(
					[
						'secret'         => self::NOTIFY_SECRET,
						'topic'          => $code,
						'store_code'     => $code,
						'site_secret'    => $this->get_site_secret(),
						'title'          => $title,
						'message'        => $message,
						'order_id'       => (string) $order->get_id(),
						'order_number'   => (string) $order->get_order_number(),
						'customer_name'  => $name,
						'phone'          => $phone,
						'total'          => (string) $order->get_total(),
						'currency'       => $order->get_currency(),
						'status'         => $order->get_status(),
						'url'            => $url,
						'created_at'     => $order->get_date_created() ? $order->get_date_created()->date( DATE_ATOM ) : gmdate( DATE_ATOM ),
					]
				),
			]
		);

		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) >= 300 ) {
			$message = is_wp_error( $response ) ? $response->get_error_message() : wp_remote_retrieve_body( $response );
			update_option( 'som_last_notification_error', $message );
			delete_option( 'som_last_notification_response' );
			delete_option( 'som_last_notification_sent_at' );
			$this->schedule_retry( $order_id, $attempt );
			$this->release_notification_lock( $order_id );
			return;
		}

		$this->mark_notified( $order_id );
		$this->release_notification_lock( $order_id );
		delete_option( 'som_last_notification_error' );
		update_option( 'som_last_notification_response', wp_remote_retrieve_body( $response ) );
		update_option( 'som_last_notification_sent_at', current_time( 'mysql' ) );
	}
}
