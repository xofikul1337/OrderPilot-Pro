<?php
/**
 * All AJAX action handlers.
 *
 * @package SukunaatOrderManager
 */

namespace SukunaatOrderManager;

defined( 'ABSPATH' ) || exit;

final class Ajax {

	private static ?self $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function register(): void {
		$actions = [
			'som_get_orders'    => 'handle_get_orders',
			'som_get_order_detail' => 'handle_get_order_detail',
			'som_get_counts'    => 'handle_get_counts',
			'som_get_metrics'   => 'handle_get_metrics',
			'som_get_staff_activity' => 'handle_get_staff_activity',
			'som_search_products' => 'handle_search_products',
			'som_create_order'  => 'handle_create_order',
			'som_save_note'     => 'handle_save_note',
			'som_delete_note'   => 'handle_delete_note',
			'som_update_status' => 'handle_update_status',
			'som_bulk_delete'   => 'handle_bulk_delete',
			'som_bulk_status'   => 'handle_bulk_status',
		];

		foreach ( $actions as $action => $method ) {
			add_action( 'wp_ajax_' . $action, [ $this, $method ] );
		}
	}

	// ── Security ──────────────────────────────────────────────────────────

	private function verify_request(): void {
		if ( ! check_ajax_referer( 'som_nonce', 'nonce', false ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed.', 'sukunaat-order-manager' ) ], 403 );
		}
		if ( ! current_user_can( 'manage_som_orders' ) && ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'sukunaat-order-manager' ) ], 403 );
		}
	}

	private function int( string $key, int $default = 0 ): int {
		return isset( $_POST[ $key ] ) ? (int) $_POST[ $key ] : $default;
	}

	private function str( string $key, string $default = '' ): string {
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : $default;
	}

	private function int_array( string $key ): array {
		if ( ! isset( $_POST[ $key ] ) || ! is_array( $_POST[ $key ] ) ) {
			return [];
		}
		return array_map( 'intval', $_POST[ $key ] );
	}

	private function can_manage_order( \WC_Order $order ): bool {
		if ( current_user_can( 'manage_woocommerce' ) ) {
			return true;
		}

		$assigned_to = (int) $order->get_meta( '_som_assigned_to', true );
		return $assigned_to < 1 || $assigned_to === get_current_user_id();
	}

	private function claim_order_if_needed( \WC_Order $order ): void {
		$user_id = get_current_user_id();
		if ( $user_id < 1 ) {
			return;
		}

		$assigned_to = (int) $order->get_meta( '_som_assigned_to', true );
		if ( $assigned_to > 0 ) {
			return;
		}

		$order->update_meta_data( '_som_assigned_to', $user_id );
		$order->save();

		Activity_Log::instance()->record(
			'order_claimed',
			sprintf( __( 'started handling this order as %s.', 'sukunaat-order-manager' ), wp_get_current_user()->display_name ),
			$order->get_id(),
			[ 'assigned_to' => $user_id ]
		);
	}

	// ── Handlers ──────────────────────────────────────────────────────────

	public function handle_get_orders(): void {
		$this->verify_request();

		$result = Order_Table::instance()->get_orders(
			$this->int( 'page', 1 ),
			$this->str( 'search' ),
			$this->str( 'status', 'all' ),
			$this->str( 'range', 'all' ),
			$this->str( 'date_from' ),
			$this->str( 'date_to' ),
			$this->int( 'assigned_to', -1 )
		);

		$rows = '';
		foreach ( $result['orders'] as $order ) {
			$rows .= $this->render_row( Order_Table::instance()->format_order( $order ) );
		}

		if ( '' === $rows ) {
			$rows = '<tr class="som-no-results"><td colspan="8">'
				. esc_html__( 'No orders found.', 'sukunaat-order-manager' )
				. '</td></tr>';
		}

		wp_send_json_success( [
			'html'         => $rows,
			'total'        => $result['total'],
			'pages'        => $result['pages'],
			'current_page' => $this->int( 'page', 1 ),
			'today_count'  => Order_Table::instance()->get_today_count(),
		] );
	}

	public function handle_get_counts(): void {
		$this->verify_request();
		wp_send_json_success( array_merge(
			Order_Table::instance()->get_status_counts(),
			[ 'today' => Order_Table::instance()->get_today_count() ]
		) );
	}

	public function handle_get_order_detail(): void {
		$this->verify_request();

		$order_id = $this->int( 'order_id' );
		if ( $order_id < 1 ) {
			wp_send_json_error( [ 'message' => __( 'Invalid order ID.', 'sukunaat-order-manager' ) ], 400 );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => __( 'Order not found.', 'sukunaat-order-manager' ) ], 404 );
		}
		if ( ! $this->can_manage_order( $order ) ) {
			wp_send_json_error( [ 'message' => __( 'This order is assigned to another staff member.', 'sukunaat-order-manager' ) ], 403 );
		}

		wp_send_json_success( $this->build_order_detail( $order ) );
	}

	public function handle_get_metrics(): void {
		$this->verify_request();
		wp_send_json_success( Order_Table::instance()->get_dashboard_metrics() );
	}

	public function handle_get_staff_activity(): void {
		$this->verify_request();

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'sukunaat-order-manager' ) ], 403 );
		}

		$user_id = $this->int( 'user_id' );
		$date    = $this->str( 'date', wp_date( 'Y-m-d' ) );
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			wp_send_json_error( [ 'message' => __( 'Staff user not found.', 'sukunaat-order-manager' ) ], 404 );
		}

		global $wpdb;
		$table = Activity_Log::table_name();
		$start = sanitize_text_field( $date ) . ' 00:00:00';
		$end   = sanitize_text_field( $date ) . ' 23:59:59';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE user_id = %d AND created_at BETWEEN %s AND %s ORDER BY created_at DESC, id DESC",
				$user_id,
				$start,
				$end
			),
			ARRAY_A
		);

		$items = [];
		foreach ( is_array( $rows ) ? $rows : [] as $row ) {
			$items[] = [
				'action'   => $row['action'],
				'message'  => $row['message'],
				'order_id' => (int) $row['order_id'],
				'time'     => mysql2date( get_option( 'time_format' ), $row['created_at'] ),
			];
		}

		wp_send_json_success(
			[
				'staff' => [
					'id'    => $user_id,
					'name'  => $user->display_name,
					'email' => $user->user_email,
				],
				'date'  => $date,
				'items' => $items,
			]
		);
	}

	private function build_order_detail( \WC_Order $order ): array {
		$email = $order->get_billing_email();
		$phone = $order->get_billing_phone();
		$customer_orders = $this->get_customer_orders( $email, $phone );
		$total_spent = 0.0;
		$cancelled = 0;
		$duplicate_phone = 0;

		foreach ( $customer_orders as $customer_order ) {
			if ( ! $customer_order instanceof \WC_Order ) {
				continue;
			}
			$total_spent += (float) $customer_order->get_total();
			if ( 'cancelled' === $customer_order->get_status() ) {
				$cancelled++;
			}
			if ( $phone && $customer_order->get_id() !== $order->get_id() && $customer_order->get_billing_phone() === $phone ) {
				$duplicate_phone++;
			}
		}

		$items = [];
		foreach ( $order->get_items() as $item ) {
			$items[] = [
				'name'     => $item->get_name(),
				'quantity' => $item->get_quantity(),
				'total'    => wc_price( (float) $item->get_total() ),
			];
		}

		$activity = [];
		foreach ( Activity_Log::instance()->for_order( $order->get_id(), 12 ) as $row ) {
			$user = ! empty( $row['user_id'] ) ? get_userdata( (int) $row['user_id'] ) : null;
			$activity[] = [
				'user'    => $user ? $user->display_name : __( 'System', 'sukunaat-order-manager' ),
				'message' => $row['message'],
				'time'    => mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $row['created_at'] ),
			];
		}

		$address = array_filter( [
			$order->get_billing_address_1(),
			$order->get_billing_address_2(),
			$order->get_billing_city(),
			$order->get_billing_state(),
			$order->get_billing_postcode(),
		] );

		return [
			'id'             => $order->get_id(),
			'order_number'   => $order->get_order_number(),
			'name'           => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'phone'          => $phone,
			'email'          => $email,
			'address'        => implode( ', ', $address ),
			'status'         => $order->get_status(),
			'status_label'   => wc_get_order_status_name( $order->get_status() ),
			'total'          => wc_price( (float) $order->get_total() ),
			'payment_method' => $order->get_payment_method_title(),
			'date'           => $order->get_date_created() ? $order->get_date_created()->date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) : '',
			'note'           => (string) $order->get_meta( Notes::META_KEY, true ),
			'assigned_to'    => (int) $order->get_meta( '_som_assigned_to', true ),
			'assigned_name'  => $this->get_assigned_name( (int) $order->get_meta( '_som_assigned_to', true ) ),
			'items'          => $items,
			'intelligence'   => [
				'orders'          => count( $customer_orders ),
				'total_spent'     => wc_price( $total_spent ),
				'cancelled'       => $cancelled,
				'duplicate_phone' => $duplicate_phone,
			],
			'activity'       => $activity,
		];
	}

	private function get_assigned_name( int $user_id ): string {
		if ( $user_id < 1 ) {
			return '';
		}
		$user = get_userdata( $user_id );
		return $user ? $user->display_name : '';
	}

	private function get_customer_orders( string $email, string $phone ): array {
		$orders = [];

		if ( $email ) {
			$orders = wc_get_orders(
				[
					'limit'         => -1,
					'type'          => 'shop_order',
					'return'        => 'objects',
					'billing_email' => $email,
				]
			);
		}

		if ( empty( $orders ) && $phone ) {
			$orders = wc_get_orders(
				[
					'limit'      => -1,
					'type'       => 'shop_order',
					'return'     => 'objects',
					'meta_query' => [
						[
							'key'     => '_billing_phone',
							'value'   => $phone,
							'compare' => '=',
						],
					],
				]
			);
		}

		return is_array( $orders ) ? $orders : [];
	}

	public function handle_search_products(): void {
		$this->verify_request();

		$term = $this->str( 'term' );
		if ( strlen( $term ) < 2 ) {
			wp_send_json_success( [] );
		}

		$products = wc_get_products(
			[
				'limit'   => 12,
				'status'  => 'publish',
				'type'    => [ 'simple', 'variation' ],
				's'       => $term,
				'orderby' => 'title',
				'order'   => 'ASC',
			]
		);

		$items = [];
		foreach ( $products as $product ) {
			if ( ! $product instanceof \WC_Product ) {
				continue;
			}
			$items[] = [
				'id'    => $product->get_id(),
				'name'  => $product->get_name(),
				'price' => wc_price( (float) $product->get_price() ),
				'sku'   => $product->get_sku(),
			];
		}

		wp_send_json_success( $items );
	}

	public function handle_create_order(): void {
		$this->verify_request();

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'sukunaat-order-manager' ) ], 403 );
		}

		$name       = $this->str( 'customer_name' );
		$phone      = $this->str( 'phone' );
		$address    = $this->str( 'address' );
		$product_id = $this->int( 'product_id' );
		$quantity   = max( 1, $this->int( 'quantity', 1 ) );
		$note       = isset( $_POST['note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['note'] ) ) : '';

		if ( '' === $name || '' === $phone || '' === $address || $product_id < 1 ) {
			wp_send_json_error( [ 'message' => __( 'Please fill customer name, phone, address and product.', 'sukunaat-order-manager' ) ], 400 );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			wp_send_json_error( [ 'message' => __( 'Product not found.', 'sukunaat-order-manager' ) ], 404 );
		}

		$order = wc_create_order( [ 'created_via' => 'sukunaat-order-manager' ] );
		if ( is_wp_error( $order ) ) {
			wp_send_json_error( [ 'message' => $order->get_error_message() ], 500 );
		}

		$name_parts = preg_split( '/\s+/', trim( $name ), 2 );
		$first_name = $name_parts[0] ?? $name;
		$last_name  = $name_parts[1] ?? '';

		$order->add_product( $product, $quantity );
		$order->set_address(
			[
				'first_name' => $first_name,
				'last_name'  => $last_name,
				'phone'      => $phone,
				'address_1'  => $address,
			],
			'billing'
		);
		$order->update_meta_data( '_som_manual_order', 'yes' );
		$order->update_meta_data( '_som_assigned_to', get_current_user_id() );
		if ( '' !== trim( $note ) ) {
			$order->update_meta_data( Notes::META_KEY, $note );
		}
		$order->calculate_totals();

		if ( ! defined( 'SOM_STATUS_CHANGE' ) ) {
			define( 'SOM_STATUS_CHANGE', true );
		}
		$order->update_status( 'confirmed', __( 'Manual order created via OrderPilot Pro.', 'sukunaat-order-manager' ) );
		$order->save();

		Activity_Log::instance()->record(
			'manual_order_created',
			sprintf( __( 'created manual confirmed order for %s.', 'sukunaat-order-manager' ), $name ),
			$order->get_id(),
			[ 'product_id' => $product_id, 'quantity' => $quantity ]
		);

		wp_send_json_success(
			[
				'message'      => __( 'Order created and confirmed.', 'sukunaat-order-manager' ),
				'order_id'     => $order->get_id(),
				'order_number' => $order->get_order_number(),
			]
		);
	}

	public function handle_save_note(): void {
		$this->verify_request();

		$order_id = $this->int( 'order_id' );
		$note     = isset( $_POST['note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['note'] ) ) : '';

		if ( $order_id < 1 ) {
			wp_send_json_error( [ 'message' => __( 'Invalid order ID.', 'sukunaat-order-manager' ) ], 400 );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => __( 'Order not found.', 'sukunaat-order-manager' ) ], 404 );
		}
		if ( ! $this->can_manage_order( $order ) ) {
			wp_send_json_error( [ 'message' => __( 'This order is assigned to another staff member.', 'sukunaat-order-manager' ) ], 403 );
		}
		$this->claim_order_if_needed( $order );

		$saved = Notes::instance()->save( $order_id, $note );
		if ( ! $saved ) {
			wp_send_json_error( [ 'message' => __( 'Order not found.', 'sukunaat-order-manager' ) ], 404 );
		}

		// ENSURE: move to on-hold for pending OR processing when note saved.
		$auto_hold = [ 'pending', 'processing' ];
		if ( '' !== trim( $note ) && in_array( $order->get_status(), $auto_hold, true ) ) {
			if ( ! defined( 'SOM_STATUS_CHANGE' ) ) {
				define( 'SOM_STATUS_CHANGE', true );
			}
			$order->update_status( 'on-hold', __( 'Status set to On Hold automatically when admin note was added.', 'sukunaat-order-manager' ) );
		}

		Activity_Log::instance()->record(
			'note_saved',
			__( 'saved an order note.', 'sukunaat-order-manager' ),
			$order_id,
			[ 'status' => $order->get_status() ]
		);

		wp_send_json_success( [
			'message'      => __( 'Note saved.', 'sukunaat-order-manager' ),
			'status'       => $order->get_status(),
			'status_label' => wc_get_order_status_name( $order->get_status() ),
			'assigned_name' => $this->get_assigned_name( (int) $order->get_meta( '_som_assigned_to', true ) ),
			'counts'       => Order_Table::instance()->get_status_counts(),
		] );
	}

	public function handle_delete_note(): void {
		$this->verify_request();

		$order_id = $this->int( 'order_id' );
		if ( $order_id < 1 ) {
			wp_send_json_error( [ 'message' => __( 'Invalid order ID.', 'sukunaat-order-manager' ) ], 400 );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => __( 'Order not found.', 'sukunaat-order-manager' ) ], 404 );
		}
		if ( ! $this->can_manage_order( $order ) ) {
			wp_send_json_error( [ 'message' => __( 'This order is assigned to another staff member.', 'sukunaat-order-manager' ) ], 403 );
		}
		$this->claim_order_if_needed( $order );

		$deleted = Notes::instance()->delete( $order_id );
		if ( ! $deleted ) {
			wp_send_json_error( [ 'message' => __( 'Order not found.', 'sukunaat-order-manager' ) ], 404 );
		}

		Activity_Log::instance()->record(
			'note_deleted',
			__( 'deleted an order note.', 'sukunaat-order-manager' ),
			$order_id
		);

		wp_send_json_success( [
			'message' => __( 'Note deleted.', 'sukunaat-order-manager' ),
			'counts'  => Order_Table::instance()->get_status_counts(),
		] );
	}

	public function handle_update_status(): void {
		$this->verify_request();

		$order_id   = $this->int( 'order_id' );
		$action     = $this->str( 'status_action' );
		$new_status = Order_Status::action_to_status( $action );

		if ( $order_id < 1 || '' === $new_status ) {
			wp_send_json_error( [ 'message' => __( 'Invalid request.', 'sukunaat-order-manager' ) ], 400 );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => __( 'Order not found.', 'sukunaat-order-manager' ) ], 404 );
		}
		if ( ! $this->can_manage_order( $order ) ) {
			wp_send_json_error( [ 'message' => __( 'This order is assigned to another staff member.', 'sukunaat-order-manager' ) ], 403 );
		}
		$this->claim_order_if_needed( $order );

		if ( ! defined( 'SOM_STATUS_CHANGE' ) ) {
			define( 'SOM_STATUS_CHANGE', true );
		}
		$old_status = $order->get_status();
		$order->update_status( $new_status, __( 'Updated via OrderPilot Pro.', 'sukunaat-order-manager' ) );

		Activity_Log::instance()->record(
			'status_updated',
			sprintf(
				__( 'changed status from %1$s to %2$s.', 'sukunaat-order-manager' ),
				wc_get_order_status_name( $old_status ),
				wc_get_order_status_name( $order->get_status() )
			),
			$order_id,
			[ 'from' => $old_status, 'to' => $order->get_status() ]
		);

		wp_send_json_success( [
			'message'      => __( 'Status updated.', 'sukunaat-order-manager' ),
			'status'       => $order->get_status(),
			'status_label' => wc_get_order_status_name( $order->get_status() ),
			'assigned_name' => $this->get_assigned_name( (int) $order->get_meta( '_som_assigned_to', true ) ),
			'counts'       => Order_Table::instance()->get_status_counts(),
		] );
	}

	public function handle_bulk_delete(): void {
		$this->verify_request();
		if ( ! current_user_can( 'delete_posts' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'sukunaat-order-manager' ) ], 403 );
		}

		$ids = $this->int_array( 'order_ids' );
		if ( empty( $ids ) ) {
			wp_send_json_error( [ 'message' => __( 'No orders selected.', 'sukunaat-order-manager' ) ], 400 );
		}

		$deleted = Order_Table::instance()->bulk_delete( $ids );

		Activity_Log::instance()->record(
			'bulk_deleted',
			sprintf( __( 'deleted %d orders in bulk.', 'sukunaat-order-manager' ), $deleted ),
			0,
			[ 'order_ids' => $ids ]
		);

		wp_send_json_success( [
			'message' => sprintf( _n( '%d order deleted.', '%d orders deleted.', $deleted, 'sukunaat-order-manager' ), $deleted ),
			'deleted' => $deleted,
			'counts'  => Order_Table::instance()->get_status_counts(),
		] );
	}

	public function handle_bulk_status(): void {
		$this->verify_request();

		$ids        = $this->int_array( 'order_ids' );
		$new_status = Order_Status::action_to_status( $this->str( 'status_action' ) );

		if ( empty( $ids ) || '' === $new_status ) {
			wp_send_json_error( [ 'message' => __( 'Invalid request.', 'sukunaat-order-manager' ) ], 400 );
		}

		if ( ! defined( 'SOM_STATUS_CHANGE' ) ) {
			define( 'SOM_STATUS_CHANGE', true );
		}

		$updated = 0;
		foreach ( $ids as $id ) {
			$order = wc_get_order( $id );
			if ( $order ) {
				if ( ! $this->can_manage_order( $order ) ) {
					continue;
				}
				$this->claim_order_if_needed( $order );
				$old_status = $order->get_status();
				$order->update_status( $new_status, __( 'Bulk updated via OrderPilot Pro.', 'sukunaat-order-manager' ) );
				Activity_Log::instance()->record(
					'bulk_status_updated',
					sprintf(
						__( 'changed status from %1$s to %2$s in bulk.', 'sukunaat-order-manager' ),
						wc_get_order_status_name( $old_status ),
						wc_get_order_status_name( $order->get_status() )
					),
					(int) $id,
					[ 'from' => $old_status, 'to' => $order->get_status() ]
				);
				$updated++;
			}
		}

		wp_send_json_success( [
			'message' => sprintf( _n( '%d order updated.', '%d orders updated.', $updated, 'sukunaat-order-manager' ), $updated ),
			'updated' => $updated,
			'counts'  => Order_Table::instance()->get_status_counts(),
		] );
	}

	// ── Row renderer ──────────────────────────────────────────────────────

	private function render_row( array $d ): string {
		$has_note = '' !== $d['note'];
		ob_start();
		?>
		<tr data-order-id="<?php echo esc_attr( $d['id'] ); ?>">
			<td class="som-col-cb">
				<label class="som-checkbox-label">
					<input type="checkbox" class="som-row-check" value="<?php echo esc_attr( $d['id'] ); ?>">
					<span class="som-checkmark"></span>
				</label>
			</td>
			<td class="som-col-name">
				<span class="som-order-number">#<?php echo esc_html( $d['order_number'] ); ?></span>
				<strong><?php echo esc_html( $d['name'] ); ?></strong>
				<small><?php echo esc_html( $d['date'] ); ?></small>
				<span class="som-assigned-pill" data-assigned-label="<?php echo esc_attr( $d['assigned_name'] ); ?>">
					<?php echo $d['assigned_name'] ? esc_html( sprintf( __( 'Handled by %s', 'sukunaat-order-manager' ), $d['assigned_name'] ) ) : esc_html__( 'Not handled yet', 'sukunaat-order-manager' ); ?>
				</span>
			</td>
			<td class="som-col-phone">
				<?php if ( $d['phone'] ) : ?>
					<a href="tel:<?php echo esc_attr( $d['phone'] ); ?>"><?php echo esc_html( $d['phone'] ); ?></a>
				<?php else : ?>
					<span class="som-muted-val">—</span>
				<?php endif; ?>
			</td>
			<td class="som-col-address"><?php echo $d['address'] ? esc_html( $d['address'] ) : '<span class="som-muted-val">—</span>'; ?></td>
			<td class="som-col-products"><?php echo $d['products'] ? esc_html( $d['products'] ) : '<span class="som-muted-val">—</span>'; ?></td>
			<td class="som-col-note">
				<div class="som-note-wrapper">
					<?php if ( $has_note ) : ?>
						<div class="som-note-display">
							<p class="som-note-text"><?php echo esc_html( $d['note'] ); ?></p>
							<div class="som-note-actions">
								<button class="som-btn-edit-note">✏️ <?php esc_html_e( 'Edit', 'sukunaat-order-manager' ); ?></button>
								<button class="som-btn-delete-note">🗑 <?php esc_html_e( 'Delete', 'sukunaat-order-manager' ); ?></button>
							</div>
						</div>
					<?php else : ?>
						<button class="som-btn-add-note">＋ <?php esc_html_e( 'Add Note', 'sukunaat-order-manager' ); ?></button>
					<?php endif; ?>
					<div class="som-note-editor" style="display:none;">
						<textarea class="som-note-input" rows="3" placeholder="<?php esc_attr_e( 'Enter note…', 'sukunaat-order-manager' ); ?>"><?php echo esc_textarea( $d['note'] ); ?></textarea>
						<div class="som-note-editor-actions">
							<button class="som-btn-save-note som-btn-primary"><?php esc_html_e( 'Save', 'sukunaat-order-manager' ); ?></button>
							<button class="som-btn-cancel-note som-btn-ghost"><?php esc_html_e( 'Cancel', 'sukunaat-order-manager' ); ?></button>
						</div>
					</div>
				</div>
			</td>
			<td class="som-col-status">
				<span class="som-status-badge som-status--<?php echo esc_attr( $d['status'] ); ?>">
					<?php echo esc_html( $d['status_label'] ); ?>
				</span>
			</td>
			<td class="som-col-actions">
				<div class="som-action-dropdown">
					<button class="som-action-toggle" aria-haspopup="true" aria-expanded="false">
						Actions <span class="som-chevron">▾</span>
					</button>
					<ul class="som-action-menu" role="menu">
						<li><button data-action="confirm"         role="menuitem">✅ <?php esc_html_e( 'Confirm Order',    'sukunaat-order-manager' ); ?></button></li>
						<li><button data-action="pending"         role="menuitem">• <?php esc_html_e( 'Pending',          'sukunaat-order-manager' ); ?></button></li>
						<li><button data-action="on-hold"         role="menuitem">⏸ <?php esc_html_e( 'On Hold',          'sukunaat-order-manager' ); ?></button></li>
						<li><button data-action="sent-to-courier" role="menuitem">🚚 <?php esc_html_e( 'Sent To Courier', 'sukunaat-order-manager' ); ?></button></li>
						<li class="som-action-sep"></li>
						<li class="som-action-danger"><button data-action="cancel" role="menuitem">✖ <?php esc_html_e( 'Cancel Order', 'sukunaat-order-manager' ); ?></button></li>
					</ul>
				</div>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}
}
