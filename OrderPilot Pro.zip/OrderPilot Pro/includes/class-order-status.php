<?php
/**
 * Registers custom WooCommerce order statuses.
 *
 * Custom statuses:
 *  - wc-sent-to-courier  (Sent To Courier)
 *  - wc-confirmed        (Confirmed — set by admin via plugin only)
 *
 * @package SukunaatOrderManager
 */

namespace SukunaatOrderManager;

defined( 'ABSPATH' ) || exit;

final class Order_Status {

	private static ?self $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function register(): void {
		add_action( 'init',                               [ $this, 'register_statuses' ] );
		add_filter( 'wc_order_statuses',                  [ $this, 'add_to_order_statuses' ] );
		add_filter( 'woocommerce_reports_order_statuses', [ $this, 'add_to_reports' ] );

		// Block CartFlows / WC from auto-moving COD orders to processing.
		add_filter( 'woocommerce_payment_complete_order_status', [ $this, 'keep_pending_on_payment' ], 99, 3 );
		add_action( 'woocommerce_order_status_changed',          [ $this, 'block_auto_processing' ],   99, 4 );
	}

	public function register_statuses(): void {
		// Sent To Courier
		register_post_status( 'wc-sent-to-courier', [
			'label'                     => _x( 'Sent To Courier', 'Order status', 'sukunaat-order-manager' ),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Sent To Courier <span class="count">(%s)</span>', 'Sent To Courier <span class="count">(%s)</span>', 'sukunaat-order-manager' ),
		] );

		// Confirmed (admin-only)
		register_post_status( 'wc-confirmed', [
			'label'                     => _x( 'Confirmed', 'Order status', 'sukunaat-order-manager' ),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Confirmed <span class="count">(%s)</span>', 'Confirmed <span class="count">(%s)</span>', 'sukunaat-order-manager' ),
		] );
	}

	public function add_to_order_statuses( array $statuses ): array {
		$statuses['wc-sent-to-courier'] = _x( 'Sent To Courier', 'Order status', 'sukunaat-order-manager' );
		$statuses['wc-confirmed']       = _x( 'Confirmed',        'Order status', 'sukunaat-order-manager' );
		return $statuses;
	}

	public function add_to_reports( array $statuses ): array {
		$statuses[] = 'sent-to-courier';
		$statuses[] = 'confirmed';
		return $statuses;
	}

	/**
	 * Block WC/CartFlows from auto-setting COD orders to processing.
	 * Only real online payments (Stripe, PayPal, bKash etc.) should auto-process.
	 */
	public function keep_pending_on_payment( string $status, int $order_id, \WC_Order $order ): string {
		if ( defined( 'SOM_STATUS_CHANGE' ) && SOM_STATUS_CHANGE ) {
			return $status;
		}
		$manual = [ 'cod', 'bacs', 'cheque', '' ];
		if ( in_array( $order->get_payment_method(), $manual, true ) && 'processing' === $status ) {
			return 'pending';
		}
		return $status;
	}

	public function block_auto_processing( int $order_id, string $from, string $to, \WC_Order $order ): void {
		if ( defined( 'SOM_STATUS_CHANGE' ) && SOM_STATUS_CHANGE ) {
			return;
		}
		if ( 'pending' !== $from || 'processing' !== $to ) {
			return;
		}
		// Allow real online gateways.
		$online = [ 'stripe', 'paypal', 'bkash', 'nagad', 'sslcommerz', 'shurjopay', 'razorpay' ];
		foreach ( $online as $gw ) {
			if ( strpos( $order->get_payment_method(), $gw ) !== false ) {
				return;
			}
		}
		// Revert to pending.
		remove_action( 'woocommerce_order_status_changed', [ $this, 'block_auto_processing' ], 99 );
		$order->update_status( 'pending', 'Kept as Pending by OrderPilot Pro.' );
		add_action( 'woocommerce_order_status_changed', [ $this, 'block_auto_processing' ], 99, 4 );
	}

	/**
	 * Map action button → WC status slug.
	 * "confirm" now → wc-confirmed (our custom status, NOT wc-processing).
	 */
	public static function action_to_status( string $action ): string {
		return [
			'confirm'         => 'confirmed',      // custom status
			'pending'         => 'pending',
			'on-hold'         => 'on-hold',
			'sent-to-courier' => 'sent-to-courier',
			'cancel'          => 'cancelled',
		][ $action ] ?? '';
	}
}
