<?php
/**
 * Stores staff/order activity for audit history.
 *
 * @package SukunaatOrderManager
 */

namespace SukunaatOrderManager;

defined( 'ABSPATH' ) || exit;

final class Activity_Log {

	private static ?self $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public static function table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'som_activity_log';
	}

	public static function install(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table = self::table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			action VARCHAR(80) NOT NULL DEFAULT '',
			message TEXT NOT NULL,
			context LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY order_id (order_id),
			KEY action (action),
			KEY created_at (created_at)
		) {$charset_collate};";

		dbDelta( $sql );
	}

	public function record( string $action, string $message, int $order_id = 0, array $context = [] ): void {
		global $wpdb;

		$wpdb->insert(
			self::table_name(),
			[
				'user_id'    => get_current_user_id(),
				'order_id'   => $order_id,
				'action'     => sanitize_key( $action ),
				'message'    => sanitize_text_field( $message ),
				'context'    => $context ? wp_json_encode( $context ) : null,
				'created_at' => current_time( 'mysql' ),
			],
			[ '%d', '%d', '%s', '%s', '%s', '%s' ]
		);
	}

	public function recent( int $limit = 20 ): array {
		global $wpdb;

		$limit = max( 1, min( 100, $limit ) );
		$table = self::table_name();

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY created_at DESC, id DESC LIMIT %d",
				$limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : [];
	}

	public function for_order( int $order_id, int $limit = 20 ): array {
		global $wpdb;

		if ( $order_id < 1 ) {
			return [];
		}

		$limit = max( 1, min( 100, $limit ) );
		$table = self::table_name();

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE order_id = %d ORDER BY created_at DESC, id DESC LIMIT %d",
				$order_id,
				$limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : [];
	}
}
