<?php
/**
 * Plugin Loader — bootstraps all components.
 *
 * @package SukunaatOrderManager
 */

namespace SukunaatOrderManager;

defined( 'ABSPATH' ) || exit;

/**
 * Singleton Loader.
 */
final class Loader {

	/** @var self|null */
	private static ?self $instance = null;

	/** Private constructor — use ::instance(). */
	private function __construct() {}

	/**
	 * Return the single instance.
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Require all class files and register hooks.
	 */
	public function init(): void {
		$this->require_files();
		$this->register_hooks();
	}

	/** Require all includes. */
	private function require_files(): void {
		$dir = SOM_PLUGIN_DIR . 'includes/';
		require_once $dir . 'class-order-status.php';
		require_once $dir . 'class-notes.php';
		require_once $dir . 'class-activity-log.php';
		require_once $dir . 'class-order-table.php';
		require_once $dir . 'class-staff-page.php';
		require_once $dir . 'class-reports.php';
		require_once $dir . 'class-notifications.php';
		require_once $dir . 'class-admin-menu.php';
		require_once $dir . 'class-ajax.php';
	}

	/** Register all WordPress hooks. */
	private function register_hooks(): void {
		$this->maybe_install();

		// Custom order status.
		Order_Status::instance()->register();

		// Push notifications — registered early, outside is_admin() so WC order hooks fire on frontend.
		Notifications::instance()->register();

		// Admin menu.
		if ( is_admin() ) {
			Admin_Menu::instance()->register();
		}

		// AJAX handlers (both logged-in and admin).
		Ajax::instance()->register();
	}

	private function maybe_install(): void {
		if ( get_option( 'som_install_version' ) === SOM_VERSION ) {
			return;
		}

		Activity_Log::install();
		Staff_Page::install_role();
		Notifications::install();
		update_option( 'som_install_version', SOM_VERSION );
	}
}
